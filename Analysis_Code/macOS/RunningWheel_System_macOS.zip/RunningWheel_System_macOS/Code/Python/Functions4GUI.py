#Functions4GUI

# This file contains the functions that the GUI will need to call in order to execute wheel analysis and data download.

#Download_file:
def RunningWheel_Download(Spinner_Email_Address, Spinner_Email_Password, Alert_Email_Address, Alert_Threshold, Python_Directory, Downloaded_SpinnerData, Python_timezone, Spinner_List):
	#This script will only download the data. It will not analyze.
	#This is good to use if you are short on time but still want to download the new data and make sure that all spinners are working properly.

	import os, re   # os allows you to change make changes to files and paths; re allows you to work with regular expressions.
	import GETdata_wheel    #This is a module that I created to download the running wheel data from email.
	from openpyxl import load_workbook, Workbook    #This module must be downloaded as a third party module to work with excel files.
	from inbox import get_inbox #This is a module and function necessary for getting the email information.

	os.chdir(Python_Directory)

	GETdata_wheel.GETdata_wheel(Spinner_Email_Address, Spinner_Email_Password, Alert_Email_Address, Alert_Threshold, Python_Directory, Downloaded_SpinnerData, Python_timezone, Spinner_List)   #Calls the GETdata_wheel function.


#Data Transfer (no wifi):
def RunningWheel_Download_nowifi(Python_Directory, spinlogs, Downloaded_SpinnerData, Spinner_List):
	import os, re   # os allows you to change make changes to files and paths; re allows you to work with regular expressions.
	import GETdata_wheel_nowifi    #This is a module that I created to download the running wheel data from email.
	from openpyxl import load_workbook, Workbook    #This module must be downloaded as a third party module to work with excel files.
	from inbox import get_inbox #This is a module and function necessary for getting the email information.

	os.chdir(Python_Directory)

	GETdata_wheel_nowifi.GETdata_wheel_nowifi(Python_Directory, spinlogs, Downloaded_SpinnerData, Spinner_List)


#Analysis_file:
def RunningWheel_Analysis(Python_Directory, MATLAB_RunningWheel_Directory):
	import os
	import matlab.engine

	eng = matlab.engine.start_matlab()

	os.chdir(MATLAB_RunningWheel_Directory)

	eng.addpath(MATLAB_RunningWheel_Directory);
	eng.Wheel_Analysis(Python_Directory, nargout=0);


#Graph_file:
def RunningWheel_PlotWheel(Python_Directory, MATLAB_RunningWheel_Directory):
	import os
	import matlab.engine

	eng = matlab.engine.start_matlab()

	os.chdir(MATLAB_RunningWheel_Directory);

	eng.addpath(MATLAB_RunningWheel_Directory);
	eng.Wheel_Plot(Python_Directory, nargout=0);





