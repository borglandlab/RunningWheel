%% Plotting Running Wheel Data
function Wheel_Plot(Python_Directory)

[Directory_Structure] = Import_MAINTable(Python_Directory);

addpath(Directory_Structure.MATLAB_GeneralDirectory)
addpath(Directory_Structure.MATLAB_RunningWheelDirectory)
PATH_dataload = Directory_Structure.Downloaded_SpinnerData; %This is the folder path where your saved data is located.
PATH_destination1 = Directory_Structure.MATLAB_PrimarySaved; %This is the location where you plan to save your figures.
PATH_destination2 = Directory_Structure.MATLAB_SecondarySaved;   %This is the secondary location where you plan to save your figures (I saved my figures twice).

timezone = Directory_Structure.MATLAB_TimeZone;  %This should be changed to your preferred time zone.
Acclimation_day1 = datetime(Directory_Structure.Acclimation_Day1, 'Format', 'd-MMM-yyyy'); % This should be the first day of the acclimation phase
%Baseline_day1 = Acclimation_day1 + 2;    % This should be the first day of the baseline
%Restriction_final = Acclimation_day1 + 19;    % This should be the last day of the experiment - only use afterwards once the experiment is done.
Restriction_final = datetime('now','Format','d-MMM-yyyy');
%Today = datetime('now','Format','d-MMM-yyyy');
% This tells the code to check to see if today's date is before the final
% experimental day. If it is, then the function will use today's date
% instead of the final restriction date.
%if Restriction_final > Today
%    Restriction_final = Today
%end

Structure = Directory_Structure.MATLAB_RunningWheel_Structure; % name of the MATLAB structure that contains/will contain the running wheel data

clear Directory_Structure

% Calling directory path
cd(PATH_dataload)   %Changes the file directory to where my data is stored.

if isfile(Structure)    %Checks to make sure that the file exists before doing anything.
    load(Structure)
end

%% Plotting the distance (m) and velocity (m/h)
disp('creating graphs');
for n = 1:length(WheelData)
    name = char(WheelDirectory(n+1).name);  %Gets name of wheel for titles.
    if ~isempty(WheelDirectory(n+1).table)
        if ~isempty(WheelData(n).Alldata)   %Checks to make sure that there is data on the table before plotting

            figure;
            %The first plot is of the total distance travelled. This is an
            %accumulation throughout the entire experiment.
            ax1 = subplot(2,1,1); hold on;
            plot(WheelData(n).Alldata.Date(WheelData(n).Alldata.Left_greater), WheelData(n).Alldata.Distance_km(WheelData(n).Alldata.Left_greater), 'r*');
            plot(WheelData(n).Alldata.Date(WheelData(n).Alldata.Right_greater), WheelData(n).Alldata.Distance_km(WheelData(n).Alldata.Right_greater), 'b*');
            plot(WheelData(n).Alldata.Date, WheelData(n).Alldata.Distance_km, 'k-');
            x1 = datetime(Acclimation_day1,'TimeZone',timezone);
            x2 = datetime(Restriction_final,'TimeZone',timezone);  %Use this onece you've gotten to the last day of the experiment
            %ylim([0 250]); %I can turn this on if I want to standardize my graphs.
            xlim([x1,x2]);
            if length(name) > 9
                title(['Spinner #' name(9:10) newline char(WheelData(n).Alldata.Date(1)) ' to ' char(WheelData(n).Alldata.Date(length(WheelData(n).Alldata.Date))) newline 'Total Distance: ' num2str(WheelData(n).Alldata.Distance_km(end)) 'km' newline 'Average Speed: ' num2str(mean(WheelData(n).Alldata.Velocity_km_h)) 'km/h']);
            else
                title(['Spinner #' name(9) newline char(WheelData(n).Alldata.Date(1)) ' to ' char(WheelData(n).Alldata.Date(length(WheelData(n).Alldata.Date))) newline 'Total Distance: ' num2str(WheelData(n).Alldata.Distance_km(end)) 'km' newline 'Average Speed: ' num2str(mean(WheelData(n).Alldata.Velocity_km_h)) 'km/h']);
            end
            ylabel('Distance (km)');
            xlabel('Time (Date)');
            legend('clock wise', 'counter-clock wise', 'Location', 'North West');
            hold off

            %The second plot is of the velocity at any given point.
            ax2 = subplot(2,1,2); hold on;
            plot(WheelData(n).Alldata.Date(WheelData(n).Alldata.Left_greater), WheelData(n).Alldata.Velocity_km_h(WheelData(n).Alldata.Left_greater), 'r*');
            plot(WheelData(n).Alldata.Date(WheelData(n).Alldata.Right_greater), WheelData(n).Alldata.Velocity_km_h(WheelData(n).Alldata.Right_greater), 'b*');
            ylim([0 5])
            %title(['Velocity of Mouse #' name(9) newline char(WheelData(n).Alldata.Date(1)) ' to ' char(WheelData(n).Alldata.Date(length(WheelData(n).Alldata.Date)))]);
            ylabel('Velocity (km/h)');
            xlabel('Time (Date)');
            %I linked my x-axis together.
            linkaxes([ax1, ax2], 'x');
            hold off
            %Saving my figures.
            cd(PATH_destination1)
            saveas(gcf,['Mouse_' num2str(n) '_Activity'],'tiff')
            cd(PATH_destination2)
            saveas(gcf,['Mouse_' num2str(n) '_Activity'],'tiff')
        else
            if length(name) > 9
                disp(['no data to show for spinner #' name(9:10)]);
            else
                disp(['no data to show for spinner #' name(9)]);
            end
        end
    else
        if length(name) > 9
            disp(['no data to show for spinner #' name(9:10)]);
        else
            disp(['no data to show for spinner #' name(9)]);
        end
    end
end
clear n name ax1 ax2 x1 x2

disp('Wheel Plots Complete');
end