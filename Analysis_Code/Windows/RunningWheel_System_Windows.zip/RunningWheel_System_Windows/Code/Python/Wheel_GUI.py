import os
import tkinter as tk
from tkinter import *
from tkinter import filedialog, ttk
from openpyxl import load_workbook

#window = Tk()

def open_GUI():
    window = Tk()
    window.title('Running Wheel GUI')
    window.geometry("440x440")

    # Create a main frame
    main_frame = Frame(window)
    main_frame.pack(fill=BOTH, expand=1)

    # Create a canvas
    my_canvas = Canvas(main_frame)
    my_canvas.pack(side=LEFT, fill=BOTH, expand=1)

    # Add a scrollbar to the canvas
    my_scrollbar = ttk.Scrollbar(main_frame, orient=VERTICAL, command=my_canvas.yview)
    my_scrollbar.pack(side=RIGHT, fill=Y)

    # Configure the canvas
    my_canvas.configure(yscrollcommand=my_scrollbar.set)
    my_canvas.bind('<Configure>', lambda e: my_canvas.configure(scrollregion = my_canvas.bbox("all")))

    # Create another frame inside the canvas
    second_frame = Frame(my_canvas)

    # Add that new frame to a window in the canvas
    my_canvas.create_window((0,0), window=second_frame, anchor="nw")


    instructions = tk.Label(master=second_frame, text='Select the appropriate analysis')
    instructions.config(font=("Arial", 20))
    instructions.pack()

    frame_2 = tk.Frame(master=second_frame, relief = tk.GROOVE, borderwidth=5)
    frame_2.config(bg="blue")
    frame_2.pack()
    button_2 = tk.Button(master=frame_2, text='Data Download', width=35, height=1)
    button_2.config(font=("Arial", 14))
    button_2.pack()
    instructions_2 = tk.Label(master=second_frame, text='- this will download running wheel data from email and\nstore in files on your computer')
    instructions_2.config(font=("Times", 12))
    instructions_2.pack()

    frame_10 = tk.Frame(master=second_frame, relief=tk.GROOVE, borderwidth=5)
    frame_10.config(bg="cyan")
    frame_10.pack()
    button_10 = tk.Button(master=frame_10, text='Data Transfer - No Wifi', width=35, height=1)
    button_10.config(font=("Arial", 14))
    button_10.pack()
    instructions_10 = tk.Label(master=second_frame, text='- use this to transfer spinner data following\nthe no wifi protocol')
    instructions_10.config(font=("Times", 12))
    instructions_10.pack()

    frame_3 = tk.Frame(master=second_frame, relief = tk.GROOVE, borderwidth=5)
    frame_3.config(bg="blue")
    frame_3.pack()
    button_3 = tk.Button(master=frame_3, text='Data Analysis', width=35, height=1)
    button_3.config(font=("Arial", 14))
    button_3.pack()
    instructions_3= tk.Label(master=second_frame, text='- this will create a MATLAB structure with your data and\ncalculate the total distance and average velocity')
    instructions_3.config(font=("Times", 12))
    instructions_3.pack()

    frame_4 = tk.Frame(master=second_frame, relief = tk.GROOVE, borderwidth=5)
    frame_4.config(bg="blue")
    frame_4.pack()
    button_4 = tk.Button(master=frame_4, text='Plot Graphs', width=35, height=1)
    button_4.config(font=("Arial", 14))
    button_4.pack()
    instructions_4 = tk.Label(master=second_frame, text='- this will plot graphs of the total distance travelled and\nthe average velocity during this time')
    instructions_4.config(font=("Times", 12))
    instructions_4.pack()

    frame_5 = tk.Frame(master=second_frame, relief = tk.GROOVE, borderwidth=5)
    frame_5.config(bg="blue")
    frame_5.pack()
    button_5 = tk.Button(master=frame_5, text='Data Download and Analysis', width=35, height=1)
    button_5.config(font=("Arial", 14))
    button_5.pack()
    instructions_5 = tk.Label(master=second_frame, text='- this will download data from your email and perform\nthe MATLAB analysis as explained above')
    instructions_5.config(font=("Times", 12))
    instructions_5.pack()

    frame_6 = tk.Frame(master=second_frame, relief = tk.GROOVE, borderwidth=5)
    frame_6.config(bg="blue")
    frame_6.pack()
    button_6 = tk.Button(master=frame_6, text='Data Analysis and Plot Graphs', width=35, height=1)
    button_6.config(font=("Arial", 14))
    button_6.pack()
    instructions_6 = tk.Label(master=second_frame, text='- this will perform the MATLAB analysis and\nplot graphs as explained above')
    instructions_6.config(font=("Times", 12))
    instructions_6.pack()

    frame_7 = tk.Frame(master=second_frame, relief = tk.GROOVE, borderwidth=5)
    frame_7.config(bg="yellow")
    frame_7.pack()
    button_7 = tk.Button(master=frame_7, text='Data Download, Analysis, and Plot Graphs', width=35, height=1)
    button_7.config(font=("Arial", 14))
    button_7.pack()
    instructions_7 = tk.Label(master=second_frame, text='- this will download data from your email, perform the\nMATLAB analysis, and plot graphs as explained above\n- CLICK THIS TO DO EVERYTHING IN ONE STEP')
    instructions_7.config(font=("Times", 12))
    instructions_7.pack()

    frame_9 = tk.Frame(master=second_frame, relief = tk.GROOVE, borderwidth=5)
    frame_9.config(bg="white")
    frame_9.pack()
    button_9 = tk.Button(master=frame_9, text='Close GUI', width=35, height=1)
    button_9.config(font=("Arial", 14))
    button_9.pack()


    import Functions4GUI

    def Download(event):
        os.chdir(Python_Directory)
        print('\nBeginning to download Mouse Spinner data from ' + Spinner_Email_Address)
        Functions4GUI.RunningWheel_Download(Spinner_Email_Address, Spinner_Email_Password, Alert_Email_Address, Alert_Threshold, Python_Directory, Downloaded_SpinnerData, Python_TimeZone, Spinner_List)
        print('\nDownload complete')

    button_2.bind("<Button-1>", Download)

    def Transfer_nowifi(event):
        
        def Get_spinlog():
            branch =Tk()
            branch.title('Select spinlog')
            branch.geometry("440x100")

            # Creating the buttons for the spinlog
            frame_branch_1 = tk.Frame(master=branch, relief = tk.GROOVE, borderwidth=5)
            frame_branch_1.config(bg="cyan")
            frame_branch_1.pack()
            button_branch_1 = tk.Button(master=frame_branch_1, text='Select location of the spinlogs', width=35, height=2)
            button_branch_1.config(font=("Arial", 14))
            button_branch_1.pack()

            def SpinLog(event):

                print('\nSelect the location of the spinlogs')
                directory_input = filedialog.askdirectory()

                global spinlogs
                spinlogs = directory_input + '/'

                os.chdir(Python_Directory)
                print('Location of spinlogs selected\n\nSpinlog data will now be transfered')

                branch.destroy()

                os.chdir(Python_Directory)
                print('\nBeginning to transfer, parse and organize mouse spinner data from \n' + Downloaded_SpinnerData + '\n')
                Functions4GUI.RunningWheel_Download_nowifi(Python_Directory, spinlogs, Downloaded_SpinnerData, Spinner_List)
                print('\nData transfer complete')

            button_branch_1.bind("<Button-1>", SpinLog)

        Get_spinlog()

    button_10.bind("<Button-1>", Transfer_nowifi)

    def Analysis(event):
        os.chdir(Python_Directory)
        print('\nBeginning Analysis of Mouse Spinner Data\nPlease be patient as this can be very time consuming')
        Functions4GUI.RunningWheel_Analysis(Python_Directory, MATLAB_RunningWheel_Directory)
        print('\nAnalysis completed')

    button_3.bind("<Button-1>", Analysis)

    def Graphs(event):
        os.chdir(Python_Directory)
        print('\nCreating graphs with Mouse Spinner Data')
        Functions4GUI.RunningWheel_PlotWheel(Python_Directory, MATLAB_RunningWheel_Directory)
        print('\nGraphs completed\nThey can be found at the following locations:\n' + MATLAB_PrimarySaved + '\n' + MATLAB_SecondarySaved)

    button_4.bind("<Button-1>", Graphs)

    def Download_Analysis(event):
        os.chdir(Python_Directory)
        print('\nBeginning to download Mouse Spinner data from ' + Spinner_Email_Address)
        Functions4GUI.RunningWheel_Download(Spinner_Email_Address, Spinner_Email_Password, Alert_Email_Address, Alert_Threshold, Python_Directory, Downloaded_SpinnerData, Python_TimeZone, Spinner_List)
        print('\nDownload complete')
        print('\nBeginning Analysis of Mouse Spinner Data\nPlease be patient as this can be very time consuming')
        Functions4GUI.RunningWheel_Analysis(Python_Directory, MATLAB_RunningWheel_Directory)
        print('\nGraphs completed\nThey can be found at the following locations:\n' + MATLAB_PrimarySaved + '\n' + MATLAB_SecondarySaved)

    button_5.bind("<Button-1>", Download_Analysis)

    def Analysis_Graphs(event):
        os.chdir(Python_Directory)
        print('\nBeginning Analysis of Mouse Spinner Data\nPlease be patient as this can be very time consuming')
        Functions4GUI.RunningWheel_Analysis(Python_Directory, MATLAB_RunningWheel_Directory)
        print('\nAnalysis completed')
        print('\nCreating graphs with Mouse Spinner Data')
        Functions4GUI.RunningWheel_PlotWheel(Python_Directory, MATLAB_RunningWheel_Directory)
        print('\nGraphs completed\nThey can be found at the following locations:\n' + MATLAB_PrimarySaved + '\n' + MATLAB_SecondarySaved)

    button_6.bind("<Button-1>", Analysis_Graphs)

    def Download_Analysis_Graphs(event):
        os.chdir(Python_Directory)
        print('\nBeginning to download Mouse Spinner data from ' + Spinner_Email_Address)
        Functions4GUI.RunningWheel_Download(Spinner_Email_Address, Spinner_Email_Password, Alert_Email_Address, Alert_Threshold, Python_Directory, Downloaded_SpinnerData, Python_TimeZone, Spinner_List)
        print('\nDownload complete')
        print('\nBeginning Analysis of Mouse Spinner Data\nPlease be patient as this can be very time consuming')
        Functions4GUI.RunningWheel_Analysis(Python_Directory, MATLAB_RunningWheel_Directory)
        print('\nAnalysis completed')
        print('\nCreating graphs with Mouse Spinner Data')
        Functions4GUI.RunningWheel_PlotWheel(Python_Directory, MATLAB_RunningWheel_Directory)
        print('\nGraphs completed\nThey can be found at the following locations:\n' + MATLAB_PrimarySaved + '\n' + MATLAB_SecondarySaved)

    button_7.bind("<Button-1>", Download_Analysis_Graphs)

    def Close_GUI(event):
        window.quit()
        window.destroy()

    button_9.bind("<Button-1>", Close_GUI)

    window.mainloop()

def Get_Directories():
    root =Tk()
    root.title('Running Wheel GUI')
    root.geometry("440x100")

    #root.withdraw()
    #root.attributes('-topmost', True)

    # Creating the buttons for the python code
    frame_1 = tk.Frame(master=root, relief = tk.GROOVE, borderwidth=5)
    frame_1.config(bg="blue")
    frame_1.pack()
    button_1 = tk.Button(master=frame_1, text='Select location of the Python code', width=35, height=2)
    button_1.config(font=("Arial", 14))
    button_1.pack()

    def PythonCode(event):
        print('\nSelect the location of the Python code')
        directory_input = filedialog.askdirectory()

        global Python_Directory
        global MATLAB_RunningWheel_Directory
        global MATLAB_General_Directory
        global Downloaded_SpinnerData
        global MATLAB_PrimarySaved
        global MATLAB_SecondarySaved

        global First_Day
        global MATLAB_RunningWheel_Structure

        global MATLAB_TimeZone
        global Python_TimeZone

        global Spinner_Email_Address
        global Spinner_Email_Password
        global Alert_Email_Address
        global Alert_Threshold
        global Spinner_Number
        global Spinner_List

        Python_Directory = directory_input + '/'

        os.chdir(Python_Directory)
        print('Location of Python code selected\n\nRunning Wheel GUI is ready')

        wb = load_workbook('RunningWheel_Setup.xlsx')
        ws = wb['Directory']

        MATLAB_RunningWheel_Directory = str(ws.cell(row=3, column=2).value)
        MATLAB_General_Directory = str(ws.cell(row=4, column=2).value)
        Downloaded_SpinnerData = str(ws.cell(row=5, column=2).value)
        MATLAB_PrimarySaved = str(ws.cell(row=6, column=2).value)
        MATLAB_SecondarySaved = str(ws.cell(row=7, column=2).value)

        First_Day = str(ws.cell(row=8, column=2).value)
        MATLAB_RunningWheel_Structure = str(ws.cell(row=9, column=2).value)

        MATLAB_TimeZone = str(ws.cell(row=10, column=2).value)
        Python_TimeZone = str(ws.cell(row=11, column=2).value)

        Spinner_Email_Address = str(ws.cell(row=12, column=2).value)
        Spinner_Email_Password = str(ws.cell(row=13, column=2).value)
        Alert_Email_Address = str(ws.cell(row=14, column=2).value)
        Alert_Threshold = str(ws.cell(row=15, column=2).value)
        Spinner_Number = str(ws.cell(row=16, column=2).value)

        Spinner_List = ['Spinner_1']
        for n in range(int(Spinner_Number)-1):
            Spinner_List.append('Spinner_' + str(n + 2))

        root.destroy()

        open_GUI()
        
    button_1.bind("<Button-1>", PythonCode)

    root.mainloop()

Get_Directories()
