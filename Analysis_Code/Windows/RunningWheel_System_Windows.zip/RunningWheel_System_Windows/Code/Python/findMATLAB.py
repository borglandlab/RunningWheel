import matlab.engine
import re
from subprocess import call

directory = matlab.engine.__file__
m = re.search('matlab', directory).start()
call(['open', directory[0:m]])