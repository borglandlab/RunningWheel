import os
from openpyxl import load_workbook, Workbook
from datetime import datetime
from datetime import timedelta
import shutil
import tkinter as tk
from tkinter import *
from tkinter import ttk
from tkinter import filedialog

window = Tk()
window.title('Running Wheel Setup for ABA protocol')
window.geometry("440x400")

# Create a main frame
main_frame = Frame(window)
main_frame.pack(fill=BOTH, expand=1)

# Create a canvas
my_canvas = Canvas(main_frame)
my_canvas.pack(side=LEFT, fill=BOTH, expand=1)

# Add a scrollbar to the canvas
my_scrollbar = ttk.Scrollbar(main_frame, orient=VERTICAL, command=my_canvas.yview)
my_scrollbar.pack(side=RIGHT, fill=Y)

# Configure the canvas
my_canvas.configure(yscrollcommand=my_scrollbar.set)
my_canvas.bind('<Configure>', lambda e: my_canvas.configure(scrollregion = my_canvas.bbox("all")))

# Create another frame inside the canvas
second_frame = Frame(my_canvas)

# Add that new frame to a window in the canvas
my_canvas.create_window((0,0), window=second_frame, anchor="nw")


instructions = tk.Label(master=second_frame, text='Define paths and directories\nfor Running Wheel Systems')
instructions.config(font=("Arial", 20))
instructions.pack()

# Creating the buttons for the python code
frame_1 = tk.Frame(master=second_frame, relief = tk.GROOVE, borderwidth=5)
frame_1.config(bg="blue")
frame_1.pack()
button_1 = tk.Button(master=frame_1, text='Select location of Python code\n(MUST SELECT FIRST)', width=35, height=2)
button_1.config(font=("Arial", 14))
button_1.pack()

def PythonCode(event):
    print('\nSelect the location of the Python code')
    directory_input = filedialog.askdirectory()
    Python_Directory = directory_input + '/'
    ws_Directory.cell(row=2, column=2).value = Python_Directory
    wb.save(str(ws_Directory.cell(row=2, column=2).value) + 'RunningWheel_Setup_ABA.xlsx')
    print('Location of Python code selected')

button_1.bind("<Button-1>", PythonCode)

# Creating the funciton for the running wheel code button
def open_wheel_buttons():
    wheel_buttons = Toplevel()
    wheel_buttons.title('Selecting paths and directories for running wheel')
    wheel_buttons.geometry("440x400")

    # Create a main frame
    main_wheel_frame = Frame(wheel_buttons)
    main_wheel_frame.pack(fill=BOTH, expand=1)

    # Create a canvas
    wheel_canvas = Canvas(main_wheel_frame)
    wheel_canvas.pack(side=LEFT, fill=BOTH, expand=1)

    # Add a scrollbar to the canvas
    wheel_scrollbar = ttk.Scrollbar(main_wheel_frame, orient=VERTICAL, command=wheel_canvas.yview)
    wheel_scrollbar.pack(side=RIGHT, fill=Y)

    # Configure the canvas
    wheel_canvas.configure(yscrollcommand=wheel_scrollbar.set)
    wheel_canvas.bind('<Configure>', lambda e: wheel_canvas.configure(scrollregion = wheel_canvas.bbox("all")))

    # Create another frame inside the canvas
    second_wheel_frame = Frame(wheel_canvas)

    # Add that new frame to a window in the canvas
    wheel_canvas.create_window((0,0), window=second_wheel_frame, anchor="nw")

    instructions_wheel_buttons = tk.Label(master=second_wheel_frame, text='Select the paths and directories for\ndata download and wheel analysis')
    instructions_wheel_buttons.config(font=("Arial", 20))
    instructions_wheel_buttons.pack()

    frame_1_wheel = tk.Frame(master=second_wheel_frame, relief = tk.GROOVE, borderwidth=5)
    frame_1_wheel.config(bg="green")
    frame_1_wheel.pack()
    button_1_wheel = tk.Button(master=frame_1_wheel, text='Select location of your\nMATLAB Running Wheel code', width=35, height=2)
    button_1_wheel.config(font=("Arial", 14))
    button_1_wheel.pack()

    def MATLAB_RunningWheel(event):
        print('\nSelect the location of the MATLAB Running Wheel code')
        directory_input = filedialog.askdirectory()
        MATLAB_RunningWheel_Directory = directory_input + '/'
        ws_Directory.cell(row=3, column=2).value = MATLAB_RunningWheel_Directory
        wb.save(str(ws_Directory.cell(row=2, column=2).value) + 'RunningWheel_Setup_ABA.xlsx')
        print('Location of the MATLAB Running Wheel code selected')

    button_1_wheel.bind("<Button-1>", MATLAB_RunningWheel)

    frame_2_wheel = tk.Frame(master=second_wheel_frame, relief = tk.GROOVE, borderwidth=5)
    frame_2_wheel.config(bg="green")
    frame_2_wheel.pack()
    button_2_wheel = tk.Button(master=frame_2_wheel, text='Select location of your\ngeneral MATLAB folder', width=35, height=2)
    button_2_wheel.config(font=("Arial", 14))
    button_2_wheel.pack()
    instructions_2_wheel = tk.Label(master=second_wheel_frame, text='- this is typically found in your Documents,\nand it is where your general MATLAB functions are stored')
    instructions_2_wheel.config(font=("Times", 12))
    instructions_2_wheel.pack()

    def MATLAB_General(event):
        print('\nSelect the location of the General MATLAB code')
        directory_input = filedialog.askdirectory()
        MATLAB_General_Directory = directory_input + '/'
        ws_Directory.cell(row=4, column=2).value = MATLAB_General_Directory
        wb.save(str(ws_Directory.cell(row=2, column=2).value) + 'RunningWheel_Setup_ABA.xlsx')
        print('Location of the General MATLAB code selected')

    button_2_wheel.bind("<Button-1>", MATLAB_General)

    frame_3_wheel = tk.Frame(master=second_wheel_frame, relief = tk.GROOVE, borderwidth=5)
    frame_3_wheel.config(bg="green")
    frame_3_wheel.pack()
    button_3_wheel = tk.Button(master=frame_3_wheel, text='Select the location where you\nwould like to store downloaded Spinner data', width=35, height=2)
    button_3_wheel.config(font=("Arial", 14))
    button_3_wheel.pack()

    def Spinner_Data(event):
        print('\nSelect the location to store downloaded Spinner data')
        directory_input = filedialog.askdirectory()
        SpinnerData_Directory = directory_input + '/'
        ws_Directory.cell(row=5, column=2).value = SpinnerData_Directory
        wb.save(str(ws_Directory.cell(row=2, column=2).value) + 'RunningWheel_Setup_ABA.xlsx')
        print('Location to store downloaded Spinner data selected')

    button_3_wheel.bind("<Button-1>", Spinner_Data)

    frame_4_wheel = tk.Frame(master=second_wheel_frame, relief = tk.GROOVE, borderwidth=5)
    frame_4_wheel.config(bg="green")
    frame_4_wheel.pack()
    button_4_wheel = tk.Button(master=frame_4_wheel, text='Select the primary location where you\nwould like to save your MATLAB data', width=35, height=2)
    button_4_wheel.config(font=("Arial", 14))
    button_4_wheel.pack()

    def MATLAB_1(event):
        print('\nSelect the primary location where you would like to save\nyour MATLAB data')
        directory_input = filedialog.askdirectory()
        MATLAB_1_Directory = directory_input + '/'
        ws_Directory.cell(row=6, column=2).value = MATLAB_1_Directory
        wb.save(str(ws_Directory.cell(row=2, column=2).value) + 'RunningWheel_Setup_ABA.xlsx')
        print('Primary location to save MATLAB data selected')

    button_4_wheel.bind("<Button-1>", MATLAB_1)

    frame_5_wheel = tk.Frame(master=second_wheel_frame, relief = tk.GROOVE, borderwidth=5)
    frame_5_wheel.config(bg="green")
    frame_5_wheel.pack()
    button_5_wheel = tk.Button(master=frame_5_wheel, text='Select the secondary location where you\nwould like to save your MATLAB data', width=35, height=2)
    button_5_wheel.config(font=("Arial", 14))
    button_5_wheel.pack()

    def MATLAB_2(event):
        print('\nSelect the secondary location where you would like to save\nyour MATLAB data')
        directory_input = filedialog.askdirectory()
        MATLAB_2_Directory = directory_input + '/'
        ws_Directory.cell(row=7, column=2).value = MATLAB_2_Directory
        wb.save(str(ws_Directory.cell(row=2, column=2).value) + 'RunningWheel_Setup_ABA.xlsx')
        print('Secondary location to save MATLAB data selected')

    button_5_wheel.bind("<Button-1>", MATLAB_2)

    frame_6_wheel = tk.Frame(master=second_wheel_frame, relief = tk.GROOVE, borderwidth=5)
    frame_6_wheel.config(bg="white")
    frame_6_wheel.pack()
    button_6_wheel = tk.Button(master=frame_6_wheel, text='Click to Close', width=35, height=1)
    button_6_wheel.config(font=("Arial", 14))
    button_6_wheel.pack()

    def Close_wheel_GUI(event):
        #wheel_buttons.quit()
        wheel_buttons.destroy()

    button_6_wheel.bind("<Button-1>", Close_wheel_GUI)


frame_2 = tk.Frame(master=second_frame, relief = tk.GROOVE, borderwidth=5)
frame_2.config(bg="green")
frame_2.pack()
button_2 = tk.Button(master=frame_2, text='Select paths and directories\nfor the running wheel', width=35, height=2)
button_2.config(font=("Arial", 14))
button_2.pack()

def RunningWheelCode(event):
    open_wheel_buttons()
    print('\nYou can now select the paths and directories where the code\nis found to run and analyze the running wheels.')

button_2.bind("<Button-1>", RunningWheelCode)



# Creating the ABA WorkSheet

def open_ABA_setup():
    File_Template = 'ABA_Template.xlsx'

    ABA_buttons = Toplevel()
    ABA_buttons.title('Setting up the ABA WorkSheet')
    ABA_buttons.geometry("440x400")

    # Create a main frame
    main_ABA_frame = Frame(ABA_buttons)
    main_ABA_frame.pack(fill=BOTH, expand=1)

    # Create a canvas
    ABA_canvas = Canvas(main_ABA_frame)
    ABA_canvas.pack(side=LEFT, fill=BOTH, expand=1)

    # Add a scrollbar to the canvas
    ABA_scrollbar = ttk.Scrollbar(main_ABA_frame, orient=VERTICAL, command=ABA_canvas.yview)
    ABA_scrollbar.pack(side=RIGHT, fill=Y)

    # Configure the canvas
    ABA_canvas.configure(yscrollcommand=ABA_scrollbar.set)
    ABA_canvas.bind('<Configure>', lambda e: ABA_canvas.configure(scrollregion = ABA_canvas.bbox("all")))

    # Create another frame inside the canvas
    second_ABA_frame = Frame(ABA_canvas)

    # Add that new frame to a window in the canvas
    ABA_canvas.create_window((0,0), window=second_ABA_frame, anchor="nw")


    instructions_ABA_buttons = tk.Label(master=second_ABA_frame, text='Select to set up the\nABA WorkSheet')
    instructions_ABA_buttons.config(font=("Arial", 20))
    instructions_ABA_buttons.pack()

    frame_1_ABA = tk.Frame(master=second_ABA_frame, relief = tk.GROOVE, borderwidth=5)
    frame_1_ABA.config(bg="magenta")
    frame_1_ABA.pack()
    button_1_ABA = tk.Button(master=frame_1_ABA, text='Select location of the\nABA_Template.xlsx', width=35, height=2)
    button_1_ABA.config(font=("Arial", 14))
    button_1_ABA.pack()

    def ABA_Location(event):
        print('\nSelect the location of the ABA_Template.xlsx')
        directory_input = filedialog.askdirectory()
        global ABA_Directory
        ABA_Directory = directory_input + '/'
        print('Location of the ABA_Template.xlsx selected')

    button_1_ABA.bind("<Button-1>", ABA_Location)

    Trial_Label = Label(second_ABA_frame, text='\nWhat trial number is this for the experiment?\nEnter a number:')
    Trial_Label.config(font=("Arial", 14))
    Trial_Label.pack()

    text_trial_frame = tk.Frame(master=second_ABA_frame, relief = tk.GROOVE, borderwidth=5)
    text_trial_frame.config(bg="magenta")
    text_trial_frame.pack()
    trial_text = Text(text_trial_frame, width=30, height=1, font=("Helvetica", 14))
    trial_text.pack()

    trial_submit_frame = tk.Frame(master=second_ABA_frame, relief = tk.GROOVE, borderwidth=5)
    trial_submit_frame.config(bg="magenta")
    trial_submit_frame.pack()

    Trial_display_frame = tk.Frame(master=second_ABA_frame, relief = tk.GROOVE, borderwidth=5)
    Trial_display_frame.config(bg="magenta")
    Trial_display_frame.pack()

    Trial_display_label = Label(second_ABA_frame, text='', font=("Helvetica", 14))
    Trial_display_label.pack()

    def display_trial(Trial_Num):
        Trial_display_label.config(text='The trial number has been set to ' + Trial_Num)

    def get_trial():
        global Trial_Num
        Trial_Num = trial_text.get(1.0, END)
        display_trial(Trial_Num[0:-1])
        Trial_Num = (Trial_Num[0:-1])

    trial_submit_button = tk.Button(master=trial_submit_frame, text='Submit Trial Number', command=get_trial, width=20, height=1)
    trial_submit_button.config(font=("Arial", 14))
    trial_submit_button.pack()


    Date_Label = Label(second_ABA_frame, text='\nWhat day will the acclimation start on?\nEnter date following DD/MM/YYYY format:')
    Date_Label.config(font=("Arial", 14))
    Date_Label.pack()

    text_date_frame = tk.Frame(master=second_ABA_frame, relief = tk.GROOVE, borderwidth=5)
    text_date_frame.config(bg="black")
    text_date_frame.pack()
    date_text = Text(text_date_frame, width=30, height=1, font=("Helvetica", 14))
    date_text.pack()

    date_submit_frame = tk.Frame(master=second_ABA_frame, relief = tk.GROOVE, borderwidth=5)
    date_submit_frame.config(bg="magenta")
    date_submit_frame.pack()

    Trial_display_frame = tk.Frame(master=second_ABA_frame, relief = tk.GROOVE, borderwidth=5)
    Trial_display_frame.config(bg="magenta")
    Trial_display_frame.pack()

    Date_display_label = Label(second_ABA_frame, text='\n', font=("Helvetica", 14))
    Date_display_label.pack()

    def display_date(Start_Date):
        Date_display_label.config(text='The first day of acclimation\nhas been set to ' + Start_Date)

    def get_date():
        global Start_Date
        Start_Date = date_text.get(1.0, END)
        Start_Date = (Start_Date[0:-1])
        display_date(Start_Date)

    date_submit_button = tk.Button(master=date_submit_frame, text='Submit Acclimation Day 1', command=get_date, width=20, height=1)
    date_submit_button.config(font=("Arial", 14))
    date_submit_button.pack()

    frame_2_ABA = tk.Frame(master=second_ABA_frame, relief = tk.GROOVE, borderwidth=5)
    frame_2_ABA.config(bg="magenta")
    frame_2_ABA.pack()
    button_2_ABA = tk.Button(master=frame_2_ABA, text='Create ABA WorkSheet', width=35, height=2)
    button_2_ABA.config(font=("Arial", 14))
    button_2_ABA.pack()

    def Create_ABA(event):
        format_string = '%d/%m/%Y'
        date_object = datetime.strptime(Start_Date, format_string)
        FileNameAdd = date_object.strftime('%d%b%Y')
        AcclimationStart = date_object.strftime('%A, %b %d %Y')
        New_File = 'ABA_' + FileNameAdd + '.xlsx'

        original_path = ABA_Directory + File_Template
        new_path = ABA_Directory + New_File

        shutil.copy(original_path, new_path)

        os.chdir(ABA_Directory)

        wb = load_workbook(New_File)

        # Create Acclimation Worksheet
        source = wb['Acclimation_Template']
        target = wb.copy_worksheet(source)
        target.title = FileNameAdd

        target.cell(row=1, column=1).value = 'ABA Experiment, Trial ' + Trial_Num + ' (Acclimation Start: ' + FileNameAdd + ')'
        target.cell(row=3, column=2).value = AcclimationStart


        # Create Baseline Worksheets
        source = wb['Baseline_Template']
        Experiment_Day = 1

        Add2Days = timedelta(days=2)
        Add1Day = timedelta(days=1)

        Newdate_object = date_object + Add2Days
        newFileNameAdd = Newdate_object.strftime('%d%b%Y')
        New_dayofData = Newdate_object.strftime('%A, %b %d %Y')

        target = wb.copy_worksheet(source)
        target.title = newFileNameAdd

        target.cell(row=1, column=1).value = 'ABA Experiment, Trial ' + Trial_Num + ' (Acclimation Start: ' + FileNameAdd + ')'
        target.cell(row=2, column=2).value = 'Baseline (Day ' + str(Experiment_Day) + ')'
        target.cell(row=3, column=2).value = New_dayofData

        for n in range(1, 7):
            source = wb['Baseline_Template']
            Experiment_Day = Experiment_Day + 1
            Newdate_object = Newdate_object + Add1Day
            newFileNameAdd = Newdate_object.strftime('%d%b%Y')
            New_dayofData = Newdate_object.strftime('%A, %b %d %Y')
            target = wb.copy_worksheet(source)
            target.title = newFileNameAdd
            target.cell(row=1, column=1).value = 'ABA Experiment, Trial ' + Trial_Num + ' (Acclimation Start: ' + FileNameAdd + ')'
            target.cell(row=2, column=2).value = 'Baseline (Day ' + str(Experiment_Day) + ')'
            target.cell(row=3, column=2).value = New_dayofData


        # Create Restriction 6hrs Worksheets
        for n in range(1, 4):
            source = wb['Restriction_Template_6hrs']
            Experiment_Day = Experiment_Day + 1
            Newdate_object = Newdate_object + Add1Day
            newFileNameAdd = Newdate_object.strftime('%d%b%Y')
            New_dayofData = Newdate_object.strftime('%A, %b %d %Y')
            target = wb.copy_worksheet(source)
            target.title = newFileNameAdd
            target.cell(row=1, column=1).value = 'ABA Experiment, Trial ' + Trial_Num + ' (Acclimation Start: ' + FileNameAdd + ')'
            target.cell(row=2, column=2).value = 'Restriction 6hrs (Day ' + str(Experiment_Day) + ')'
            target.cell(row=3, column=2).value = New_dayofData


        # Create Restriction 3hrs Worksheets
        for n in range(1, 9):
            source = wb['Restriction_Template_3hrs']
            Experiment_Day = Experiment_Day + 1
            Newdate_object = Newdate_object + Add1Day
            newFileNameAdd = Newdate_object.strftime('%d%b%Y')
            New_dayofData = Newdate_object.strftime('%A, %b %d %Y')
            target = wb.copy_worksheet(source)
            target.title = newFileNameAdd
            target.cell(row=1, column=1).value = 'ABA Experiment, Trial ' + Trial_Num + ' (Acclimation Start: ' + FileNameAdd + ')'
            target.cell(row=2, column=2).value = 'Restriction 3hrs (Day ' + str(Experiment_Day) + ')'
            target.cell(row=3, column=2).value = New_dayofData


        myorder = [4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,0,1,2,3]
        wb._sheets =[wb._sheets[i] for i in myorder]
        #wb._sheets.sort(key=lambda ws: ws.title)

        # Creating a directory for my ABA.xlsx workbook
        sheet_list = wb.sheetnames
        sheet_list = sheet_list[0:-4]

        ws_directory = wb.create_sheet('Directory')
        ws_directory.cell(row=1, column=1).value = 'TabNumber'
        ws_directory.cell(row=1, column=2).value = 'TabName'
        ws_directory.cell(row=1, column=3).value = 'Date'
        ws_directory.cell(row=1, column=4).value = 'Experimental_Day'

        for n in range(len(sheet_list)):
            ws = wb[sheet_list[n]]
            ws_directory.cell(row=n+2, column=1).value = n+1
            ws_directory.cell(row=n+2, column=2).value = sheet_list[n]
            ws_directory.cell(row=n+2, column=3).value = ws.cell(row=3, column=2).value
            ws_directory.cell(row=n+2, column=4).value = ws.cell(row=2, column=2).value

        wb.save(New_File)

        print('New ABA WorkSheet created for experiment')

    button_2_ABA.bind("<Button-1>", Create_ABA)


    frame_3_ABA = tk.Frame(master=second_ABA_frame, relief = tk.GROOVE, borderwidth=5)
    frame_3_ABA.config(bg="white")
    frame_3_ABA.pack()
    button_3_ABA = tk.Button(master=frame_3_ABA, text='Click to Close', width=35, height=1)
    button_3_ABA.config(font=("Arial", 14))
    button_3_ABA.pack()

    def Close_ABA(event):
        ABA_buttons.destroy()

    button_3_ABA.bind("<Button-1>", Close_ABA)


frame_3 = tk.Frame(master=second_frame, relief = tk.GROOVE, borderwidth=5)
frame_3.config(bg="magenta")
frame_3.pack()
button_3 = tk.Button(master=frame_3, text='Set up the ABA WorkSheet', width=35, height=2)
button_3.config(font=("Arial", 14))
button_3.pack()

def ABA_Setup(event):
    open_ABA_setup()
    print('\nYou can now setup the ABA WorkSheet')

button_3.bind("<Button-1>", ABA_Setup)


# Creating the funciton for the mouse weights code button
def open_weight_buttons():
    weight_buttons = Toplevel()
    weight_buttons.title('Selecting paths and directories for mouse weights analysis')
    weight_buttons.geometry("440x400")

    # Create a main frame
    main_weight_frame = Frame(weight_buttons)
    main_weight_frame.pack(fill=BOTH, expand=1)

    # Create a canvas
    weight_canvas = Canvas(main_weight_frame)
    weight_canvas.pack(side=LEFT, fill=BOTH, expand=1)

    # Add a scrollbar to the canvas
    weight_scrollbar = ttk.Scrollbar(main_weight_frame, orient=VERTICAL, command=weight_canvas.yview)
    weight_scrollbar.pack(side=RIGHT, fill=Y)

    # Configure the canvas
    weight_canvas.configure(yscrollcommand=weight_scrollbar.set)
    weight_canvas.bind('<Configure>', lambda e: weight_canvas.configure(scrollregion = weight_canvas.bbox("all")))

    # Create another frame inside the canvas
    second_weight_frame = Frame(weight_canvas)

    # Add that new frame to a window in the canvas
    weight_canvas.create_window((0,0), window=second_weight_frame, anchor="nw")

    instructions_weight_buttons = tk.Label(master=second_weight_frame, text='Select the paths and directories for\nanalyzing mouse weights for\nthe ABA experiment')
    instructions_weight_buttons.config(font=("Arial", 20))
    instructions_weight_buttons.pack()

    frame_1_weight = tk.Frame(master=second_weight_frame, relief = tk.GROOVE, borderwidth=5)
    frame_1_weight.config(bg="red")
    frame_1_weight.pack()
    button_1_weight = tk.Button(master=frame_1_weight, text='Select location of\nMATLAB Mouse Weight code', width=35, height=2)
    button_1_weight.config(font=("Arial", 14))
    button_1_weight.pack()

    def MATLAB_MouseWeight(event):
        print('\nSelect the location where the Mouse Weight code is stored for MATLAB')
        directory_input = filedialog.askdirectory()
        MATLAB_MouseWeight_Directory = directory_input + '/'
        ws_Directory.cell(row=8, column=2).value = MATLAB_MouseWeight_Directory
        wb.save(str(ws_Directory.cell(row=2, column=2).value) + 'RunningWheel_Setup_ABA.xlsx')
        print('Location of the MATLAB Mouse Weight code selected')

    button_1_weight.bind("<Button-1>", MATLAB_MouseWeight)

    Acclim_Label = Label(second_weight_frame, text='\nEnter in the date of the first day of acclimation\nfollowing (DD/MM/YYYY) format')
    Acclim_Label.config(font=("Arial", 14))
    Acclim_Label.pack()

    text_frame = tk.Frame(master=second_weight_frame, relief = tk.GROOVE, borderwidth=5)
    text_frame.config(bg="black")
    text_frame.pack()
    acclim_text = Text(text_frame, width=30, height=1, font=("Helvetica", 14))
    acclim_text.pack()

    acclim_submit_frame = tk.Frame(master=second_weight_frame, relief = tk.GROOVE, borderwidth=5)
    acclim_submit_frame.config(bg="red")
    acclim_submit_frame.pack()

    Acclim_display_frame = tk.Frame(master=second_weight_frame, relief = tk.GROOVE, borderwidth=5)
    Acclim_display_frame.config(bg="red")
    Acclim_display_frame.pack()

    Acclim_display_label = Label(second_weight_frame, text='\n', font=("Helvetica", 14))
    Acclim_display_label.pack()

    def display_acclim(Acclim_Day):
        format_string = '%d/%m/%Y'
        date_object = datetime.strptime(Acclim_Day, format_string)
        FileNameAdd = date_object.strftime('%d%b%Y')
        AcclimationStart = date_object.strftime('%d-%b-%Y')

        RunningWheel_Structure = 'ABA_' + FileNameAdd + '.mat'
        MouseWeight_Structure = 'ABA_weight_' + FileNameAdd + '.mat'
        ABA_File = 'ABA_' + FileNameAdd + '.xlsx'
        ws_Directory.cell(row=9, column=2).value = AcclimationStart
        ws_Directory.cell(row=10, column=2).value = RunningWheel_Structure
        ws_Directory.cell(row=11, column=2).value = MouseWeight_Structure
        ws_Directory.cell(row=12, column=2).value = ABA_File

        wb.save(str(ws_Directory.cell(row=2, column=2).value) + 'RunningWheel_Setup_ABA.xlsx')

        Acclim_display_label.config(text='The first day of acclimation has\nbeen submitted as ' + Acclim_Day)

    def get_acclim():
        Acclim_Day = acclim_text.get(1.0, END)
        display_acclim(Acclim_Day[0:-1])

    acclim_submit_button = tk.Button(master=acclim_submit_frame, text='Submit Acclimation Day 1', command=get_acclim, width=20, height=1)
    acclim_submit_button.config(font=("Arial", 14))
    acclim_submit_button.pack()

    frame_3_weight = tk.Frame(master=second_weight_frame, relief = tk.GROOVE, borderwidth=5)
    frame_3_weight.config(bg="red")
    frame_3_weight.pack()
    button_3_weight = tk.Button(master=frame_3_weight, text='Select location of\nthe ABA excel file', width=35, height=2)
    button_3_weight.config(font=("Arial", 14))
    button_3_weight.pack()

    def ABA_DataSheet(event):
        print('\nSelect location of the ABA WorkSheet')
        directory_input = filedialog.askdirectory()
        ABA_Directory = directory_input + '/'
        ws_Directory.cell(row=13, column=2).value = ABA_Directory
        wb.save(str(ws_Directory.cell(row=2, column=2).value) + 'RunningWheel_Setup_ABA.xlsx')
        print('Location of the ABA WorkSheet selected')

    button_3_weight.bind("<Button-1>", ABA_DataSheet)

    frame_4_weight = tk.Frame(master=second_weight_frame, relief = tk.GROOVE, borderwidth=5)
    frame_4_weight.config(bg="white")
    frame_4_weight.pack()
    button_4_weight = tk.Button(master=frame_4_weight, text='Click to Close', width=35, height=1)
    button_4_weight.config(font=("Arial", 14))
    button_4_weight.pack()

    def Close_weight_GUI(event):
        #weight_buttons.quit()
        weight_buttons.destroy()

    button_4_weight.bind("<Button-1>", Close_weight_GUI)

frame_4 = tk.Frame(master=second_frame, relief = tk.GROOVE, borderwidth=5)
frame_4.config(bg="red")
frame_4.pack()
button_4 = tk.Button(master=frame_4, text='Selecting paths and directories\nfor mouse weights analysis', width=35, height=2)
button_4.config(font=("Arial", 14))
button_4.pack()

def MouseWeightCode(event):
    open_weight_buttons()
    print('\nYou can now select the paths and directories where the code\nis found to run and analyze the mouse weight analysis.')

button_4.bind("<Button-1>",MouseWeightCode)

# Creating the funciton for selecting the timezones for python and matlab
def Select_timezones():
    timezone_buttons = Toplevel()
    timezone_buttons.title('Selecting paths and directories for mouse weights analysis')
    timezone_buttons.geometry("440x400")

    # Create a main frame
    main_timezone_frame = Frame(timezone_buttons)
    main_timezone_frame.pack(fill=BOTH, expand=1)

    # Create a canvas
    timezone_canvas = Canvas(main_timezone_frame)
    timezone_canvas.pack(side=LEFT, fill=BOTH, expand=1)

    # Add a scrollbar to the canvas
    timezone_scrollbar = ttk.Scrollbar(main_timezone_frame, orient=VERTICAL, command=timezone_canvas.yview)
    timezone_scrollbar.pack(side=RIGHT, fill=Y)

    # Configure the canvas
    timezone_canvas.configure(yscrollcommand=timezone_scrollbar.set)
    timezone_canvas.bind('<Configure>', lambda e: timezone_canvas.configure(scrollregion = timezone_canvas.bbox("all")))

    # Create another frame inside the canvas
    second_timezone_frame = Frame(timezone_canvas)

    # Add that new frame to a window in the canvas
    timezone_canvas.create_window((0,0), window=second_timezone_frame, anchor="nw")

    instructions_timezone_buttons = tk.Label(master=second_timezone_frame, text='Select the appropriate time zone\nfor your location')
    instructions_timezone_buttons.config(font=("Arial", 20))
    instructions_timezone_buttons.pack()
    # Defining function for dropdown menu (MATLAB Timezones)
    def YourTimeZone_MATLAB(event):
        MATLABTimezone_value = Combo_1_timezone.get()
        ws_Directory.cell(row=14, column=2).value = MATLABTimezone_value
        wb.save(str(ws_Directory.cell(row=2, column=2).value) + 'RunningWheel_Setup_ABA.xlsx')

    # Creating dropdownn menu
    MATLAB_options = [
        "Select a time zone",
        "Africa/Abidjan",
        "Africa/Accra",
        "Africa/Addis_Ababa",
        "Africa/Algiers",
        "Africa/Asmera",
        "Africa/Bamako",
        "Africa/Bangui",
        "Africa/Banjul",
        "Africa/Bissau",
        "Africa/Blantyre",
        "Africa/Brazzaville",
        "Africa/Bujumbura",
        "Africa/Cairo",
        "Africa/Casablanca",
        "Africa/Ceuta",
        "Africa/Conakry",
        "Africa/Dakar",
        "Africa/Dar_es_Salaam",
        "Africa/Djibouti",
        "Africa/Douala",
        "Africa/El_Aaiun",
        "Africa/Freetown",
        "Africa/Gaborone",
        "Africa/Harare",
        "Africa/Johannesburg",
        "Africa/Juba",
        "Africa/Kampala",
        "Africa/Khartoum",
        "Africa/Kigali",
        "Africa/Kinshasa",
        "Africa/Lagos",
        "Africa/Libreville",
        "Africa/Lome",
        "Africa/Luanda",
        "Africa/Lubumbashi",
        "Africa/Lusaka",
        "Africa/Malabo",
        "Africa/Maputo",
        "Africa/Maseru",
        "Africa/Mbabane",
        "Africa/Mogadishu",
        "Africa/Monrovia",
        "Africa/Nairobi",
        "Africa/Ndjamena",
        "Africa/Niamey",
        "Africa/Nouakchott",
        "Africa/Ouagadougou",
        "Africa/Porto-Novo",
        "Africa/Sao_Tome",
        "Africa/Tripoli",
        "Africa/Tunis",
        "Africa/Windhoek",
        "America/Adak",
        "America/Anchorage",
        "America/Anguilla",
        "America/Antigua",
        "America/Araguaina",
        "America/Argentina/La_Rioja",
        "America/Argentina/Rio_Gallegos",
        "America/Argentina/Salta",
        "America/Argentina/San_Juan",
        "America/Argentina/San_Luis",
        "America/Argentina/Tucuman",
        "America/Argentina/Ushuaia",
        "America/Aruba",
        "America/Asuncion",
        "America/Bahia",
        "America/Bahia_Banderas",
        "America/Barbados",
        "America/Belem",
        "America/Belize",
        "America/Blanc-Sablon",
        "America/Boa_Vista",
        "America/Bogota",
        "America/Boise",
        "America/Buenos_Aires",
        "America/Cambridge_Bay",
        "America/Campo_Grande",
        "America/Cancun",
        "America/Caracas",
        "America/Catamarca",
        "America/Cayenne",
        "America/Cayman",
        "America/Chicago",
        "America/Chihuahua",
        "America/Coral_Harbour",
        "America/Cordoba",
        "America/Costa_Rica",
        "America/Creston",
        "America/Cuiaba",
        "America/Curacao",
        "America/Danmarkshavn",
        "America/Dawson",
        "America/Dawson_Creek",
        "America/Denver",
        "America/Detroit",
        "America/Dominica",
        "America/Edmonton",
        "America/Eirunepe",
        "America/El_Salvador",
        "America/Fort_Nelson",
        "America/Fortaleza",
        "America/Glace_Bay",
        "America/Godthab",
        "America/Goose_Bay",
        "America/Grand_Turk",
        "America/Grenada",
        "America/Guadeloupe",
        "America/Guatemala",
        "America/Guayaquil",
        "America/Guyana",
        "America/Halifax",
        "America/Havana",
        "America/Hermosillo",
        "America/Indiana/Knox",
        "America/Indiana/Marengo",
        "America/Indiana/Petersburg",
        "America/Indiana/Tell_City",
        "America/Indiana/Vevay",
        "America/Indiana/Vincennes",
        "America/Indiana/Winamac",
        "America/Indianapolis",
        "America/Inuvik",
        "America/Iqaluit",
        "America/Jamaica",
        "America/Jujuy",
        "America/Juneau",
        "America/Kentucky/Monticello",
        "America/Kralendijk",
        "America/La_Paz",
        "America/Lima",
        "America/Los_Angeles",
        "America/Louisville",
        "America/Lower_Princes",
        "America/Maceio",
        "America/Managua",
        "America/Manaus",
        "America/Marigot",
        "America/Martinique",
        "America/Matamoros",
        "America/Mazatlan",
        "America/Mendoza",
        "America/Menominee",
        "America/Merida",
        "America/Metlakatla",
        "America/Mexico_City",
        "America/Miquelon",
        "America/Moncton",
        "America/Monterrey",
        "America/Montevideo",
        "America/Montreal",
        "America/Montserrat",
        "America/Nassau",
        "America/New_York",
        "America/Nipigon",
        "America/Nome",
        "America/Noronha",
        "America/North_Dakota/Beulah",
        "America/North_Dakota/Center",
        "America/North_Dakota/New_Salem",
        "America/Ojinaga",
        "America/Panama",
        "America/Pangnirtung",
        "America/Paramaribo",
        "America/Phoenix",
        "America/Port-au-Prince",
        "America/Port_of_Spain",
        "America/Porto_Velho",
        "America/Puerto_Rico",
        "America/Punta_Arenas",
        "America/Rainy_River",
        "America/Rankin_Inlet",
        "America/Recife",
        "America/Regina",
        "America/Resolute",
        "America/Rio_Branco",
        "America/Santa_Isabel",
        "America/Santarem",
        "America/Santiago",
        "America/Santo_Domingo",
        "America/Sao_Paulo",
        "America/Scoresbysund",
        "America/Sitka",
        "America/St_Barthelemy",
        "America/St_Johns",
        "America/St_Kitts",
        "America/St_Lucia",
        "America/St_Thomas",
        "America/St_Vincent",
        "America/Swift_Current",
        "America/Tegucigalpa",
        "America/Thule",
        "America/Thunder_Bay",
        "America/Tijuana",
        "America/Toronto",
        "America/Tortola",
        "America/Vancouver",
        "America/Whitehorse",
        "America/Winnipeg",
        "America/Yakutat",
        "America/Yellowknife",
        "Antarctica/Casey",
        "Antarctica/Davis",
        "Antarctica/DumontDUrville",
        "Antarctica/Macquarie",
        "Antarctica/Mawson",
        "Antarctica/McMurdo",
        "Antarctica/Palmer",
        "Antarctica/Rothera",
        "Antarctica/Syowa",
        "Antarctica/Troll",
        "Antarctica/Vostok",
        "Arctic/Longyearbyen",
        "Asia/Aden",
        "Asia/Almaty",
        "Asia/Amman",
        "Asia/Anadyr",
        "Asia/Aqtau",
        "Asia/Aqtobe",
        "Asia/Ashgabat",
        "Asia/Atyrau",
        "Asia/Baghdad",
        "Asia/Bahrain",
        "Asia/Baku",
        "Asia/Bangkok",
        "Asia/Barnaul",
        "Asia/Beirut",
        "Asia/Bishkek",
        "Asia/Brunei",
        "Asia/Calcutta",
        "Asia/Chita",
        "Asia/Choibalsan",
        "Asia/Colombo",
        "Asia/Damascus",
        "Asia/Dhaka",
        "Asia/Dili",
        "Asia/Dubai",
        "Asia/Dushanbe",
        "Asia/Famagusta",
        "Asia/Gaza",
        "Asia/Hebron",
        "Asia/Hong_Kong",
        "Asia/Hovd",
        "Asia/Irkutsk",
        "Asia/Jakarta",
        "Asia/Jayapura",
        "Asia/Jerusalem",
        "Asia/Kabul",
        "Asia/Kamchatka",
        "Asia/Karachi",
        "Asia/Katmandu",
        "Asia/Khandyga",
        "Asia/Krasnoyarsk",
        "Asia/Kuala_Lumpur",
        "Asia/Kuching",
        "Asia/Kuwait",
        "Asia/Macau",
        "Asia/Magadan",
        "Asia/Makassar",
        "Asia/Manila",
        "Asia/Muscat",
        "Asia/Nicosia",
        "Asia/Novokuznetsk",
        "Asia/Novosibirsk",
        "Asia/Omsk",
        "Asia/Oral",
        "Asia/Phnom_Penh",
        "Asia/Pontianak",
        "Asia/Pyongyang",
        "Asia/Qatar",
        "Asia/Qostanay",
        "Asia/Qyzylorda",
        "Asia/Rangoon",
        "Asia/Riyadh",
        "Asia/Saigon",
        "Asia/Sakhalin",
        "Asia/Samarkand",
        "Asia/Seoul",
        "Asia/Shanghai",
        "Asia/Singapore",
        "Asia/Srednekolymsk",
        "Asia/Taipei",
        "Asia/Tashkent",
        "Asia/Tbilisi",
        "Asia/Tehran",
        "Asia/Thimphu",
        "Asia/Tokyo",
        "Asia/Tomsk",
        "Asia/Ulaanbaatar",
        "Asia/Urumqi",
        "Asia/Ust-Nera",
        "Asia/Vientiane",
        "Asia/Vladivostok",
        "Asia/Yakutsk",
        "Asia/Yekaterinburg",
        "Asia/Yerevan",
        "Atlantic/Azores",
        "Atlantic/Bermuda",
        "Atlantic/Canary",
        "Atlantic/Cape_Verde",
        "Atlantic/Faeroe",
        "Atlantic/Madeira",
        "Atlantic/Reykjavik",
        "Atlantic/South_Georgia",
        "Atlantic/St_Helena",
        "Atlantic/Stanley",
        "Australia/Adelaide",
        "Australia/Brisbane",
        "Australia/Broken_Hill",
        "Australia/Currie",
        "Australia/Darwin",
        "Australia/Eucla",
        "Australia/Hobart",
        "Australia/Lindeman",
        "Australia/Lord_Howe",
        "Australia/Melbourne",
        "Australia/Perth",
        "Australia/Sydney",
        "Etc/GMT",
        "Etc/GMT+1",
        "Etc/GMT+10",
        "Etc/GMT+11",
        "Etc/GMT+12",
        "Etc/GMT+2",
        "Etc/GMT+3",
        "Etc/GMT+4",
        "Etc/GMT+5",
        "Etc/GMT+6",
        "Etc/GMT+7",
        "Etc/GMT+8",
        "Etc/GMT+9",
        "Etc/GMT-1",
        "Etc/GMT-10",
        "Etc/GMT-11",
        "Etc/GMT-12",
        "Etc/GMT-13",
        "Etc/GMT-14",
        "Etc/GMT-2",
        "Etc/GMT-3",
        "Etc/GMT-4",
        "Etc/GMT-5",
        "Etc/GMT-6",
        "Etc/GMT-7",
        "Etc/GMT-8",
        "Etc/GMT-9",
        "Etc/UTC",
        "Europe/Amsterdam",
        "Europe/Andorra",
        "Europe/Astrakhan",
        "Europe/Athens",
        "Europe/Belgrade",
        "Europe/Berlin",
        "Europe/Bratislava",
        "Europe/Brussels",
        "Europe/Bucharest",
        "Europe/Budapest",
        "Europe/Busingen",
        "Europe/Chisinau",
        "Europe/Copenhagen",
        "Europe/Dublin",
        "Europe/Gibraltar",
        "Europe/Guernsey",
        "Europe/Helsinki",
        "Europe/Isle_of_Man",
        "Europe/Istanbul",
        "Europe/Jersey",
        "Europe/Kaliningrad",
        "Europe/Kiev",
        "Europe/Kirov",
        "Europe/Lisbon",
        "Europe/Ljubljana",
        "Europe/London",
        "Europe/Luxembourg",
        "Europe/Madrid",
        "Europe/Malta",
        "Europe/Mariehamn",
        "Europe/Minsk",
        "Europe/Monaco",
        "Europe/Moscow",
        "Europe/Oslo",
        "Europe/Paris",
        "Europe/Podgorica",
        "Europe/Prague",
        "Europe/Riga",
        "Europe/Rome",
        "Europe/Samara",
        "Europe/San_Marino",
        "Europe/Sarajevo",
        "Europe/Saratov",
        "Europe/Simferopol",
        "Europe/Skopje",
        "Europe/Sofia",
        "Europe/Stockholm",
        "Europe/Tallinn",
        "Europe/Tirane",
        "Europe/Ulyanovsk",
        "Europe/Uzhgorod",
        "Europe/Vaduz",
        "Europe/Vatican",
        "Europe/Vienna",
        "Europe/Vilnius",
        "Europe/Volgograd",
        "Europe/Warsaw",
        "Europe/Zagreb",
        "Europe/Zaporozhye",
        "Europe/Zurich",
        "Indian/Antananarivo",
        "Indian/Chagos",
        "Indian/Christmas",
        "Indian/Cocos",
        "Indian/Comoro",
        "Indian/Kerguelen",
        "Indian/Mahe",
        "Indian/Maldives",
        "Indian/Mauritius",
        "Indian/Mayotte",
        "Indian/Reunion",
        "Pacific/Apia",
        "Pacific/Auckland",
        "Pacific/Bougainville",
        "Pacific/Chatham",
        "Pacific/Easter",
        "Pacific/Efate",
        "Pacific/Enderbury",
        "Pacific/Fakaofo",
        "Pacific/Fiji",
        "Pacific/Funafuti",
        "Pacific/Galapagos",
        "Pacific/Gambier",
        "Pacific/Guadalcanal",
        "Pacific/Guam",
        "Pacific/Honolulu",
        "Pacific/Johnston",
        "Pacific/Kiritimati",
        "Pacific/Kosrae",
        "Pacific/Kwajalein",
        "Pacific/Majuro",
        "Pacific/Marquesas",
        "Pacific/Midway",
        "Pacific/Nauru",
        "Pacific/Niue",
        "Pacific/Norfolk",
        "Pacific/Noumea",
        "Pacific/Pago_Pago",
        "Pacific/Palau",
        "Pacific/Pitcairn",
        "Pacific/Ponape",
        "Pacific/Port_Moresby",
        "Pacific/Rarotonga",
        "Pacific/Saipan",
        "Pacific/Tahiti",
        "Pacific/Tarawa",
        "Pacific/Tongatapu",
        "Pacific/Truk",
        "Pacific/Wake",
        "Pacific/Wallis"
    ]

    instructions_1_timezone = tk.Label(master=second_timezone_frame, text='Select your MATLAB timezone from the\ndropdown menu below and press the return key')
    instructions_1_timezone.config(font=("Arial", 14))
    instructions_1_timezone.pack()
    Combo_1_timezone = ttk.Combobox(second_timezone_frame, value=MATLAB_options)
    Combo_1_timezone.current(0)
    Combo_1_timezone.bind("<<ComboboxSelected>>", YourTimeZone_MATLAB)
    Combo_1_timezone.pack()

    # Defining function for dropdown menu (Python Timezones)
    def YourTimeZone_Python(event):
        PythonTimezone_value = Combo_2_timezone.get()
        ws_Directory.cell(row=15, column=2).value = PythonTimezone_value
        wb.save(str(ws_Directory.cell(row=2, column=2).value) + 'RunningWheel_Setup_ABA.xlsx')

    # Creating dropdownn menu
    Python_options = [
        'Select a time zone',
        'Africa/Abidjan',
        'Africa/Accra',
        'Africa/Addis_Ababa',
        'Africa/Algiers',
        'Africa/Asmara',
        'Africa/Asmera',
        'Africa/Bamako',
        'Africa/Bangui',
        'Africa/Banjul',
        'Africa/Bissau',
        'Africa/Blantyre',
        'Africa/Brazzaville',
        'Africa/Bujumbura',
        'Africa/Cairo',
        'Africa/Casablanca',
        'Africa/Ceuta',
        'Africa/Conakry',
        'Africa/Dakar',
        'Africa/Dar_es_Salaam',
        'Africa/Djibouti',
        'Africa/Douala',
        'Africa/El_Aaiun',
        'Africa/Freetown',
        'Africa/Gaborone',
        'Africa/Harare',
        'Africa/Johannesburg',
        'Africa/Juba',
        'Africa/Kampala',
        'Africa/Khartoum',
        'Africa/Kigali',
        'Africa/Kinshasa',
        'Africa/Lagos',
        'Africa/Libreville',
        'Africa/Lome',
        'Africa/Luanda',
        'Africa/Lubumbashi',
        'Africa/Lusaka',
        'Africa/Malabo',
        'Africa/Maputo',
        'Africa/Maseru',
        'Africa/Mbabane',
        'Africa/Mogadishu',
        'Africa/Monrovia',
        'Africa/Nairobi',
        'Africa/Ndjamena',
        'Africa/Niamey',
        'Africa/Nouakchott',
        'Africa/Ouagadougou',
        'Africa/Porto-Novo',
        'Africa/Sao_Tome',
        'Africa/Timbuktu',
        'Africa/Tripoli',
        'Africa/Tunis',
        'Africa/Windhoek',
        'America/Adak',
        'America/Anchorage',
        'America/Anguilla',
        'America/Antigua',
        'America/Araguaina',
        'America/Argentina/Buenos_Aires',
        'America/Argentina/Catamarca',
        'America/Argentina/ComodRivadavia',
        'America/Argentina/Cordoba',
        'America/Argentina/Jujuy',
        'America/Argentina/La_Rioja',
        'America/Argentina/Mendoza',
        'America/Argentina/Rio_Gallegos',
        'America/Argentina/Salta',
        'America/Argentina/San_Juan',
        'America/Argentina/San_Luis',
        'America/Argentina/Tucuman',
        'America/Argentina/Ushuaia',
        'America/Aruba',
        'America/Asuncion',
        'America/Atikokan',
        'America/Atka',
        'America/Bahia',
        'America/Bahia_Banderas',
        'America/Barbados',
        'America/Belem',
        'America/Belize',
        'America/Blanc-Sablon',
        'America/Boa_Vista',
        'America/Bogota',
        'America/Boise',
        'America/Buenos_Aires',
        'America/Cambridge_Bay',
        'America/Campo_Grande',
        'America/Cancun',
        'America/Caracas',
        'America/Catamarca',
        'America/Cayenne',
        'America/Cayman',
        'America/Chicago',
        'America/Chihuahua',
        'America/Coral_Harbour',
        'America/Cordoba',
        'America/Costa_Rica',
        'America/Creston',
        'America/Cuiaba',
        'America/Curacao',
        'America/Danmarkshavn',
        'America/Dawson',
        'America/Dawson_Creek',
        'America/Denver',
        'America/Detroit',
        'America/Dominica',
        'America/Edmonton',
        'America/Eirunepe',
        'America/El_Salvador',
        'America/Ensenada',
        'America/Fort_Nelson',
        'America/Fort_Wayne',
        'America/Fortaleza',
        'America/Glace_Bay',
        'America/Godthab',
        'America/Goose_Bay',
        'America/Grand_Turk',
        'America/Grenada',
        'America/Guadeloupe',
        'America/Guatemala',
        'America/Guayaquil',
        'America/Guyana',
        'America/Halifax',
        'America/Havana',
        'America/Hermosillo',
        'America/Indiana/Indianapolis',
        'America/Indiana/Knox',
        'America/Indiana/Marengo',
        'America/Indiana/Petersburg',
        'America/Indiana/Tell_City',
        'America/Indiana/Vevay',
        'America/Indiana/Vincennes',
        'America/Indiana/Winamac',
        'America/Indianapolis',
        'America/Inuvik',
        'America/Iqaluit',
        'America/Jamaica',
        'America/Jujuy',
        'America/Juneau',
        'America/Kentucky/Louisville',
        'America/Kentucky/Monticello',
        'America/Knox_IN',
        'America/Kralendijk',
        'America/La_Paz',
        'America/Lima',
        'America/Los_Angeles',
        'America/Louisville',
        'America/Lower_Princes',
        'America/Maceio',
        'America/Managua',
        'America/Manaus',
        'America/Marigot',
        'America/Martinique',
        'America/Matamoros',
        'America/Mazatlan',
        'America/Mendoza',
        'America/Menominee',
        'America/Merida',
        'America/Metlakatla',
        'America/Mexico_City',
        'America/Miquelon',
        'America/Moncton',
        'America/Monterrey',
        'America/Montevideo',
        'America/Montreal',
        'America/Montserrat',
        'America/Nassau',
        'America/New_York',
        'America/Nipigon',
        'America/Nome',
        'America/Noronha',
        'America/North_Dakota/Beulah',
        'America/North_Dakota/Center',
        'America/North_Dakota/New_Salem',
        'America/Nuuk',
        'America/Ojinaga',
        'America/Panama',
        'America/Pangnirtung',
        'America/Paramaribo', 'America/Phoenix',
        'America/Port-au-Prince',
        'America/Port_of_Spain',
        'America/Porto_Acre',
        'America/Porto_Velho',
        'America/Puerto_Rico',
        'America/Punta_Arenas',
        'America/Rainy_River',
        'America/Rankin_Inlet',
        'America/Recife',
        'America/Regina',
        'America/Resolute',
        'America/Rio_Branco',
        'America/Rosario',
        'America/Santa_Isabel',
        'America/Santarem',
        'America/Santiago',
        'America/Santo_Domingo',
        'America/Sao_Paulo',
        'America/Scoresbysund',
        'America/Shiprock',
        'America/Sitka',
        'America/St_Barthelemy',
        'America/St_Johns',
        'America/St_Kitts',
        'America/St_Lucia',
        'America/St_Thomas',
        'America/St_Vincent',
        'America/Swift_Current',
        'America/Tegucigalpa',
        'America/Thule',
        'America/Thunder_Bay',
        'America/Tijuana',
        'America/Toronto',
        'America/Tortola',
        'America/Vancouver',
        'America/Virgin',
        'America/Whitehorse',
        'America/Winnipeg',
        'America/Yakutat',
        'America/Yellowknife',
        'Antarctica/Casey',
        'Antarctica/Davis',
        'Antarctica/DumontDUrville',
        'Antarctica/Macquarie',
        'Antarctica/Mawson',
        'Antarctica/McMurdo',
        'Antarctica/Palmer',
        'Antarctica/Rothera',
        'Antarctica/South_Pole',
        'Antarctica/Syowa',
        'Antarctica/Troll',
        'Antarctica/Vostok',
        'Arctic/Longyearbyen',
        'Asia/Aden',
        'Asia/Almaty',
        'Asia/Amman',
        'Asia/Anadyr',
        'Asia/Aqtau',
        'Asia/Aqtobe',
        'Asia/Ashgabat',
        'Asia/Ashkhabad',
        'Asia/Atyrau',
        'Asia/Baghdad',
        'Asia/Bahrain',
        'Asia/Baku',
        'Asia/Bangkok',
        'Asia/Barnaul',
        'Asia/Beirut',
        'Asia/Bishkek',
        'Asia/Brunei',
        'Asia/Calcutta',
        'Asia/Chita',
        'Asia/Choibalsan',
        'Asia/Chongqing',
        'Asia/Chungking',
        'Asia/Colombo',
        'Asia/Dacca',
        'Asia/Damascus',
        'Asia/Dhaka',
        'Asia/Dili',
        'Asia/Dubai',
        'Asia/Dushanbe',
        'Asia/Famagusta',
        'Asia/Gaza',
        'Asia/Harbin',
        'Asia/Hebron',
        'Asia/Ho_Chi_Minh',
        'Asia/Hong_Kong',
        'Asia/Hovd',
        'Asia/Irkutsk',
        'Asia/Istanbul',
        'Asia/Jakarta',
        'Asia/Jayapura',
        'Asia/Jerusalem',
        'Asia/Kabul',
        'Asia/Kamchatka',
        'Asia/Karachi',
        'Asia/Kashgar',
        'Asia/Kathmandu',
        'Asia/Katmandu',
        'Asia/Khandyga',
        'Asia/Kolkata',
        'Asia/Krasnoyarsk',
        'Asia/Kuala_Lumpur',
        'Asia/Kuching',
        'Asia/Kuwait',
        'Asia/Macao',
        'Asia/Macau',
        'Asia/Magadan',
        'Asia/Makassar',
        'Asia/Manila',
        'Asia/Muscat',
        'Asia/Nicosia',
        'Asia/Novokuznetsk',
        'Asia/Novosibirsk',
        'Asia/Omsk',
        'Asia/Oral',
        'Asia/Phnom_Penh',
        'Asia/Pontianak',
        'Asia/Pyongyang',
        'Asia/Qatar',
        'Asia/Qostanay',
        'Asia/Qyzylorda',
        'Asia/Rangoon',
        'Asia/Riyadh',
        'Asia/Saigon',
        'Asia/Sakhalin',
        'Asia/Samarkand',
        'Asia/Seoul',
        'Asia/Shanghai',
        'Asia/Singapore',
        'Asia/Srednekolymsk',
        'Asia/Taipei',
        'Asia/Tashkent',
        'Asia/Tbilisi',
        'Asia/Tehran',
        'Asia/Tel_Aviv',
        'Asia/Thimbu',
        'Asia/Thimphu',
        'Asia/Tokyo',
        'Asia/Tomsk',
        'Asia/Ujung_Pandang',
        'Asia/Ulaanbaatar',
        'Asia/Ulan_Bator',
        'Asia/Urumqi',
        'Asia/Ust-Nera',
        'Asia/Vientiane',
        'Asia/Vladivostok',
        'Asia/Yakutsk',
        'Asia/Yangon',
        'Asia/Yekaterinburg',
        'Asia/Yerevan',
        'Atlantic/Azores',
        'Atlantic/Bermuda',
        'Atlantic/Canary',
        'Atlantic/Cape_Verde',
        'Atlantic/Faeroe',
        'Atlantic/Faroe',
        'Atlantic/Jan_Mayen',
        'Atlantic/Madeira',
        'Atlantic/Reykjavik',
        'Atlantic/South_Georgia',
        'Atlantic/St_Helena',
        'Atlantic/Stanley',
        'Australia/ACT',
        'Australia/Adelaide',
        'Australia/Brisbane',
        'Australia/Broken_Hill',
        'Australia/Canberra',
        'Australia/Currie',
        'Australia/Darwin',
        'Australia/Eucla',
        'Australia/Hobart',
        'Australia/LHI',
        'Australia/Lindeman',
        'Australia/Lord_Howe',
        'Australia/Melbourne',
        'Australia/NSW',
        'Australia/North',
        'Australia/Perth',
        'Australia/Queensland',
        'Australia/South',
        'Australia/Sydney',
        'Australia/Tasmania',
        'Australia/Victoria',
        'Australia/West',
        'Australia/Yancowinna',
        'Brazil/Acre',
        'Brazil/DeNoronha',
        'Brazil/East',
        'Brazil/West',
        'CET',
        'CST6CDT',
        'Canada/Atlantic',
        'Canada/Central',
        'Canada/Eastern',
        'Canada/Mountain',
        'Canada/Newfoundland',
        'Canada/Pacific',
        'Canada/Saskatchewan',
        'Canada/Yukon',
        'Chile/Continental',
        'Chile/EasterIsland',
        'Cuba',
        'EET',
        'EST',
        'EST5EDT',
        'Egypt',
        'Eire',
        'Etc/GMT',
        'Etc/GMT+0',
        'Etc/GMT+1',
        'Etc/GMT+10',
        'Etc/GMT+11',
        'Etc/GMT+12',
        'Etc/GMT+2',
        'Etc/GMT+3',
        'Etc/GMT+4',
        'Etc/GMT+5',
        'Etc/GMT+6',
        'Etc/GMT+7',
        'Etc/GMT+8',
        'Etc/GMT+9',
        'Etc/GMT-0',
        'Etc/GMT-1',
        'Etc/GMT-10',
        'Etc/GMT-11',
        'Etc/GMT-12',
        'Etc/GMT-13',
        'Etc/GMT-14',
        'Etc/GMT-2',
        'Etc/GMT-3',
        'Etc/GMT-4',
        'Etc/GMT-5',
        'Etc/GMT-6',
        'Etc/GMT-7',
        'Etc/GMT-8',
        'Etc/GMT-9',
        'Etc/GMT0',
        'Etc/Greenwich',
        'Etc/UCT',
        'Etc/UTC',
        'Etc/Universal',
        'Etc/Zulu',
        'Europe/Amsterdam',
        'Europe/Andorra',
        'Europe/Astrakhan',
        'Europe/Athens',
        'Europe/Belfast',
        'Europe/Belgrade',
        'Europe/Berlin',
        'Europe/Bratislava',
        'Europe/Brussels',
        'Europe/Bucharest',
        'Europe/Budapest',
        'Europe/Busingen',
        'Europe/Chisinau',
        'Europe/Copenhagen',
        'Europe/Dublin',
        'Europe/Gibraltar',
        'Europe/Guernsey',
        'Europe/Helsinki',
        'Europe/Isle_of_Man',
        'Europe/Istanbul',
        'Europe/Jersey',
        'Europe/Kaliningrad',
        'Europe/Kiev',
        'Europe/Kirov',
        'Europe/Lisbon',
        'Europe/Ljubljana',
        'Europe/London',
        'Europe/Luxembourg',
        'Europe/Madrid',
        'Europe/Malta',
        'Europe/Mariehamn',
        'Europe/Minsk',
        'Europe/Monaco',
        'Europe/Moscow',
        'Europe/Nicosia',
        'Europe/Oslo',
        'Europe/Paris',
        'Europe/Podgorica',
        'Europe/Prague',
        'Europe/Riga',
        'Europe/Rome',
        'Europe/Samara',
        'Europe/San_Marino',
        'Europe/Sarajevo',
        'Europe/Saratov',
        'Europe/Simferopol',
        'Europe/Skopje',
        'Europe/Sofia',
        'Europe/Stockholm',
        'Europe/Tallinn',
        'Europe/Tirane',
        'Europe/Tiraspol',
        'Europe/Ulyanovsk',
        'Europe/Uzhgorod',
        'Europe/Vaduz',
        'Europe/Vatican',
        'Europe/Vienna',
        'Europe/Vilnius',
        'Europe/Volgograd',
        'Europe/Warsaw',
        'Europe/Zagreb',
        'Europe/Zaporozhye',
        'Europe/Zurich',
        'GB',
        'GB-Eire',
        'GMT',
        'GMT+0',
        'GMT-0',
        'GMT0',
        'Greenwich',
        'HST',
        'Hongkong',
        'Iceland',
        'Indian/Antananarivo',
        'Indian/Chagos',
        'Indian/Christmas',
        'Indian/Cocos',
        'Indian/Comoro',
        'Indian/Kerguelen',
        'Indian/Mahe',
        'Indian/Maldives',
        'Indian/Mauritius',
        'Indian/Mayotte',
        'Indian/Reunion',
        'Iran',
        'Israel',
        'Jamaica',
        'Japan',
        'Kwajalein',
        'Libya',
        'MET',
        'MST',
        'MST7MDT',
        'Mexico/BajaNorte',
        'Mexico/BajaSur',
        'Mexico/General',
        'NZ',
        'NZ-CHAT',
        'Navajo',
        'PRC',
        'PST8PDT',
        'Pacific/Apia',
        'Pacific/Auckland',
        'Pacific/Bougainville',
        'Pacific/Chatham',
        'Pacific/Chuuk',
        'Pacific/Easter',
        'Pacific/Efate',
        'Pacific/Enderbury',
        'Pacific/Fakaofo',
        'Pacific/Fiji',
        'Pacific/Funafuti',
        'Pacific/Galapagos',
        'Pacific/Gambier',
        'Pacific/Guadalcanal',
        'Pacific/Guam',
        'Pacific/Honolulu',
        'Pacific/Johnston',
        'Pacific/Kiritimati',
        'Pacific/Kosrae',
        'Pacific/Kwajalein',
        'Pacific/Majuro',
        'Pacific/Marquesas',
        'Pacific/Midway',
        'Pacific/Nauru',
        'Pacific/Niue',
        'Pacific/Norfolk',
        'Pacific/Noumea',
        'Pacific/Pago_Pago',
        'Pacific/Palau',
        'Pacific/Pitcairn',
        'Pacific/Pohnpei',
        'Pacific/Ponape',
        'Pacific/Port_Moresby',
        'Pacific/Rarotonga',
        'Pacific/Saipan',
        'Pacific/Samoa',
        'Pacific/Tahiti',
        'Pacific/Tarawa',
        'Pacific/Tongatapu',
        'Pacific/Truk',
        'Pacific/Wake',
        'Pacific/Wallis',
        'Pacific/Yap',
        'Poland',
        'Portugal',
        'ROC',
        'ROK',
        'Singapore',
        'Turkey',
        'UCT',
        'US/Alaska',
        'US/Aleutian',
        'US/Arizona',
        'US/Central',
        'US/East-Indiana',
        'US/Eastern',
        'US/Hawaii',
        'US/Indiana-Starke',
        'US/Michigan',
        'US/Mountain',
        'US/Pacific',
        'US/Samoa',
        'UTC',
        'Universal',
        'W-SU',
        'WET',
        'Zulu'
    ]

    instructions_2_timezone = tk.Label(master=second_timezone_frame, text='Select your Python timezone from the\ndropdown menu below and press the return key')
    instructions_2_timezone.config(font=("Arial", 14))
    instructions_2_timezone.pack()
    Combo_2_timezone = ttk.Combobox(second_timezone_frame, value=Python_options)
    Combo_2_timezone.current(0)
    Combo_2_timezone.bind("<<ComboboxSelected>>", YourTimeZone_Python)
    Combo_2_timezone.pack()

    frame_3_timezone = tk.Frame(master=second_timezone_frame, relief = tk.GROOVE, borderwidth=5)
    frame_3_timezone.config(bg="white")
    frame_3_timezone.pack()
    button_3_timezone = tk.Button(master=frame_3_timezone, text='Click to Close', width=35, height=1)
    button_3_timezone.config(font=("Arial", 14))
    button_3_timezone.pack()

    def Close_timezone_GUI(event):
        #timezone_buttons.quit()
        timezone_buttons.destroy()

    button_3_timezone.bind("<Button-1>", Close_timezone_GUI)

frame_5 = tk.Frame(master=second_frame, relief = tk.GROOVE, borderwidth=5)
frame_5.config(bg="yellow")
frame_5.pack()
button_5 = tk.Button(master=frame_5, text='Select timezones for Python and MATLAB', width=35, height=2)
button_5.config(font=("Arial", 14))
button_5.pack()

def SelectTimeZones(event):
    print('\nSelect the time zones for both the Python and MATLAB code')
    Select_timezones()

button_5.bind("<Button-1>",SelectTimeZones)

# Creating the function for inputing the email address and associated information
def EnterEmailAddress():
    email_buttons = Toplevel()
    email_buttons.title('Enter Email Address and Information')
    email_buttons.geometry("440x400")

    # Create a main frame
    main_email_frame = Frame(email_buttons)
    main_email_frame.pack(fill=BOTH, expand=1)

    # Create a canvas
    email_canvas = Canvas(main_email_frame)
    email_canvas.pack(side=LEFT, fill=BOTH, expand=1)

    # Add a scrollbar to the canvas
    email_scrollbar = ttk.Scrollbar(main_email_frame, orien=VERTICAL, command=email_canvas.yview)
    email_scrollbar.pack(side=RIGHT, fill=Y)

    # Configure the canvas
    email_canvas.configure(yscrollcommand=email_scrollbar.set)
    email_canvas.bind('<Configure>', lambda e: email_canvas.configure(scrollregion = email_canvas.bbox("all")))

    # Create another frame inside the canvas
    second_email_frame = Frame(email_canvas)

    # Add that new frame to a window in the canvas
    email_canvas.create_window((0,0), window=second_email_frame, anchor="nw")


    instructions_email_buttons = tk.Label(master=second_email_frame, text='Enter the email information\nfor the running\nwheels to function properly')
    instructions_email_buttons.config(font=("Arial", 20))
    instructions_email_buttons.pack()

    Email_Label = Label(second_email_frame, text='Enter the email address\nthat you will use to send\nand receive data from your spinners')
    Email_Label.config(font=("Arial", 14))
    Email_Label.pack()

    text_frame = tk.Frame(master=second_email_frame, relief = tk.GROOVE, borderwidth=5)
    text_frame.config(bg="black")
    text_frame.pack()
    email_text = Text(text_frame, width=30, height=1, font=("Helvetica", 14))
    email_text.pack()

    email_submit_frame = tk.Frame(master=second_email_frame, relief = tk.GROOVE, borderwidth=5)
    email_submit_frame.config(bg="cyan")
    email_submit_frame.pack()

    Email_display_frame = tk.Frame(master=second_email_frame, relief = tk.GROOVE, borderwidth=5)
    Email_display_frame.config(bg="cyan")
    Email_display_frame.pack()
    
    Email_display_label = Label(second_email_frame, text='\n\n', font=("Helvetica", 14))
    Email_display_label.pack()

    def display_email(Email_Address):
        ws_Directory.cell(row=16, column=2).value = Email_Address
        wb.save(str(ws_Directory.cell(row=2, column=2).value) + 'RunningWheel_Setup_ABA.xlsx')
        Email_display_label.config(text='The email address\n' + Email_Address + '\nhas been submitted')

    def get_email():
        Email_Address = email_text.get(1.0, END)
        display_email(Email_Address[0:-1])

    email_submit_button = tk.Button(master=email_submit_frame, text='Submit Email', command=get_email, width=20, height=1)
    email_submit_button.config(font=("Arial", 14))
    email_submit_button.pack()
    

    Password_Label = Label(second_email_frame, text='Enter the app specific password\nfor the above email address')
    Password_Label.config(font=("Arial", 14))
    Password_Label.pack()

    text_password_frame = tk.Frame(master=second_email_frame, relief = tk.GROOVE, borderwidth=5)
    text_password_frame.config(bg="black")
    text_password_frame.pack()
    password_text = Text(text_password_frame, width=30, height=1, font=("Helvetica", 14))
    password_text.pack()

    password_submit_frame = tk.Frame(master=second_email_frame, relief = tk.GROOVE, borderwidth=5)
    password_submit_frame.config(bg="cyan")
    password_submit_frame.pack()

    Password_display_frame = tk.Frame(master=second_email_frame, relief = tk.GROOVE, borderwidth=5)
    Password_display_frame.config(bg="cyan")
    Password_display_frame.pack()
    
    Password_display_label = Label(second_email_frame, text='\n\n', font=("Helvetica", 14))
    Password_display_label.pack()

    def display_password(Email_Password):
        ws_Directory.cell(row=17, column=2).value = Email_Password
        wb.save(str(ws_Directory.cell(row=2, column=2).value) + 'RunningWheel_Setup_ABA.xlsx')
        Password_display_label.config(text='The email password\n' + Email_Password + '\nhas been submitted')

    def get_password():
        Email_Password = password_text.get(1.0, END)
        display_password(Email_Password[0:-1])

    password_submit_button = tk.Button(master=password_submit_frame, text='Submit Password', command=get_password, width=20, height=1)
    password_submit_button.config(font=("Arial", 14))
    password_submit_button.pack()


    AlertEmail_Label = Label(second_email_frame, text='Enter the email address where you\nwould like the alert emails sent')
    AlertEmail_Label.config(font=("Arial", 14))
    AlertEmail_Label.pack()

    text_alertemail_frame = tk.Frame(master=second_email_frame, relief = tk.GROOVE, borderwidth=5)
    text_alertemail_frame.config(bg="black")
    text_alertemail_frame.pack()
    alertemail_text = Text(text_alertemail_frame, width=30, height=1, font=("Helvetica", 14))
    alertemail_text.pack()

    alertemail_submit_frame = tk.Frame(master=second_email_frame, relief = tk.GROOVE, borderwidth=5)
    alertemail_submit_frame.config(bg="cyan")
    alertemail_submit_frame.pack()

    AlertEmail_display_frame = tk.Frame(master=second_email_frame, relief = tk.GROOVE, borderwidth=5)
    AlertEmail_display_frame.config(bg="cyan")
    AlertEmail_display_frame.pack()
    
    AlertEmail_display_label = Label(second_email_frame, text='\n\n', font=("Helvetica", 14))
    AlertEmail_display_label.pack()

    def display_alertemail(AlertEmail):
        ws_Directory.cell(row=18, column=2).value = AlertEmail
        wb.save(str(ws_Directory.cell(row=2, column=2).value) + 'RunningWheel_Setup_ABA.xlsx')
        AlertEmail_display_label.config(text='The alert email address\n' + AlertEmail + '\nhas been submitted')

    def get_alertemail():
        AlertEmail = alertemail_text.get(1.0, END)
        display_alertemail(AlertEmail[0:-1])

    alertemail_submit_button = tk.Button(master=alertemail_submit_frame, text='Submit Alert Email', command=get_alertemail, width=20, height=1)
    alertemail_submit_button.config(font=("Arial", 14))
    alertemail_submit_button.pack()


    AlertThresh_Label = Label(second_email_frame, text='Enter the threshold at which\nan alert email will be sent Typically\nset to 3 if spinners sending emails every\nhour (number of hours passes without an\nemail being received)')
    AlertThresh_Label.config(font=("Arial", 14))
    AlertThresh_Label.pack()

    text_alertthresh_frame = tk.Frame(master=second_email_frame, relief = tk.GROOVE, borderwidth=5)
    text_alertthresh_frame.config(bg="black")
    text_alertthresh_frame.pack()
    alertthresh_text = Text(text_alertthresh_frame, width=30, height=1, font=("Helvetica", 14))
    alertthresh_text.pack()

    alertthresh_submit_frame = tk.Frame(master=second_email_frame, relief = tk.GROOVE, borderwidth=5)
    alertthresh_submit_frame.config(bg="cyan")
    alertthresh_submit_frame.pack()

    AlertThresh_display_frame = tk.Frame(master=second_email_frame, relief = tk.GROOVE, borderwidth=5)
    AlertThresh_display_frame.config(bg="cyan")
    AlertThresh_display_frame.pack()
    
    AlertThresh_display_label = Label(second_email_frame, text='\n\n', font=("Helvetica", 14))
    AlertThresh_display_label.pack()

    def display_alertthresh(AlertThresh):
        ws_Directory.cell(row=19, column=2).value = AlertThresh
        wb.save(str(ws_Directory.cell(row=2, column=2).value) + 'RunningWheel_Setup_ABA.xlsx')
        AlertThresh_display_label.config(text='An alert email will be sent if\n' + AlertThresh + ' hours passes without\nreceiving an email from that spinner')

    def get_alertthresh():
        AlertThresh = alertthresh_text.get(1.0, END)
        display_alertthresh(AlertThresh[0:-1])

    alertthresh_submit_button = tk.Button(master=alertthresh_submit_frame, text='Submit Alert Threshold', command=get_alertthresh, width=20, height=1)
    alertthresh_submit_button.config(font=("Arial", 14))
    alertthresh_submit_button.pack()


    SpinNum_Label = Label(second_email_frame, text='Enter the number of mouse spinners\nthat you will be using\n(The ABA WorkSheet and analysis is\ndesigned for 8 mouse spinners and 8 dummy wheels\nso you should enter 8 here)')
    SpinNum_Label.config(font=("Arial", 14))
    SpinNum_Label.pack()

    text_spinnum_frame = tk.Frame(master=second_email_frame, relief = tk.GROOVE, borderwidth=5)
    text_spinnum_frame.config(bg="black")
    text_spinnum_frame.pack()
    spinnum_text = Text(text_spinnum_frame, width=30, height=1, font=("Helvetica", 14))
    spinnum_text.pack()

    spinnum_submit_frame = tk.Frame(master=second_email_frame, relief = tk.GROOVE, borderwidth=5)
    spinnum_submit_frame.config(bg="cyan")
    spinnum_submit_frame.pack()

    SpinNum_display_frame = tk.Frame(master=second_email_frame, relief = tk.GROOVE, borderwidth=5)
    SpinNum_display_frame.config(bg="cyan")
    SpinNum_display_frame.pack()
    
    SpinNum_display_label = Label(second_email_frame, text='\n\n\n\n\n\n', font=("Helvetica", 14))
    SpinNum_display_label.pack()

    def display_spinnum(SpinNum):
        ws_Directory.cell(row=20, column=2).value = SpinNum
        wb.save(str(ws_Directory.cell(row=2, column=2).value) + 'RunningWheel_Setup_ABA.xlsx')
        if int(SpinNum) != 8:
            SpinNum_display_label.config(text=SpinNum + ' mouse spinners will be used for\nthis experiment\nBecause you are not using 8 mouse spinners\n(16 total mice in the ABA protocol)\nYou will need to update the code in the\nMouseWeight_Analayis.m MATLAB file before\nthe code will work')
        else: SpinNum_display_label.config(text=SpinNum + ' mouse spinners will be used for\nthis experiment\nThis corresponds with the ABA experiment of\n16 total mice\nThe MouseWeight_Analayis.m MATLAB file\nwill be ready to use\n')

    def get_spinnum():
        SpinNum = spinnum_text.get(1.0, END)
        display_spinnum(SpinNum[0:-1])

    spinnum_submit_button = tk.Button(master=spinnum_submit_frame, text='Submit Spinner Number', command=get_spinnum, width=20, height=1)
    spinnum_submit_button.config(font=("Arial", 14))
    spinnum_submit_button.pack()

    frame_2_email = tk.Frame(master=second_email_frame, relief = tk.GROOVE, borderwidth=5)
    frame_2_email.config(bg="white")
    frame_2_email.pack()
    button_2_email = tk.Button(master=frame_2_email, text='Click to Close', width=35, height=1)
    button_2_email.config(font=("Arial", 14))
    button_2_email.pack()

    def Close_email_GUI(event):
        #email_buttons.quit()
        email_buttons.destroy()

    button_2_email.bind("<Button-1>", Close_email_GUI)

frame_6 = tk.Frame(master=second_frame, relief = tk.GROOVE, borderwidth=5)
frame_6.config(bg="cyan")
frame_6.pack()
button_6 = tk.Button(master=frame_6, text='Enter Email Address and Information', width=35, height=2)
button_6.config(font=("Arial", 14))
button_6.pack()

def Email_Info(event):
    print('\nEnter Email Address and Information')
    EnterEmailAddress()

button_6.bind("<Button-1>",Email_Info)

# Open an Excel Worksheet to store the paths
wb = Workbook()
ws_Directory = wb.create_sheet('Directory')
ws_Directory.cell(row=1, column=1).value = 'Directory_Type'

ws_Directory.cell(row=2, column=1).value = 'Python_Code'

ws_Directory.cell(row=3, column=1).value = 'MATLAB_RunningWheel_Code'
ws_Directory.cell(row=4, column=1).value = 'MATLAB_General_Code'
ws_Directory.cell(row=5, column=1).value = 'DownloadedSpinnerData'
ws_Directory.cell(row=6, column=1).value = 'MATLAB_PrimarySaved'
ws_Directory.cell(row=7, column=1).value = 'MATLAB_SecondarySaved'

ws_Directory.cell(row=8, column=1).value = 'MATLAB_MouseWeight_Code'
ws_Directory.cell(row=9, column=1).value = 'Acclimation_Day1'
ws_Directory.cell(row=10, column=1).value = 'MATLAB_RunningWheel_Structure'
ws_Directory.cell(row=11, column=1).value = 'MATLAB_Weight_Structure'
ws_Directory.cell(row=12, column=1).value = 'Excel_File_Name'
ws_Directory.cell(row=13, column=1).value = 'Excel_File_Directory'

ws_Directory.cell(row=14, column=1).value = 'MATLAB_TimeZone'
ws_Directory.cell(row=15, column=1).value = 'Python_TimeZone'

ws_Directory.cell(row=16, column=1).value = 'Spinner_Email_Address'
ws_Directory.cell(row=17, column=1).value = 'Spinner_Email_Password'
ws_Directory.cell(row=18, column=1).value = 'Alert_Email_Address'
ws_Directory.cell(row=19, column=1).value = 'Alert_Threshold'
ws_Directory.cell(row=20, column=1).value = 'Spinner_Number'

ws_Directory.cell(row=1, column=2).value = 'Directory'

#wb.save(str(ws_Directory.cell(row=2, column=2).value) + 'RunningWheel_Setup_ABA.xlsx')


def open_setup_buttons():
    setup_buttons = Toplevel()
    setup_buttons.title('Run at the end of setup')
    setup_buttons.geometry("440x400")

    # Create a main frame
    main_setup_frame = Frame(setup_buttons)
    main_setup_frame.pack(fill=BOTH, expand=1)

    # Create a canvas
    setup_canvas = Canvas(main_setup_frame)
    setup_canvas.pack(side=LEFT, fill=BOTH, expand=1)

    # Add a scrollbar to the canvas
    setup_scrollbar = ttk.Scrollbar(main_setup_frame, orient=VERTICAL, command=setup_canvas.yview)
    setup_scrollbar.pack(side=RIGHT, fill=Y)

    # Configure the canvas
    setup_canvas.configure(yscrollcommand=setup_scrollbar.set)
    setup_canvas.bind('<Configure>', lambda e: setup_canvas.configure(scrollregion = setup_canvas.bbox("all")))

    # Create another frame inside the canvas
    second_setup_frame = Frame(setup_canvas)

    # Add that new frame to a window in the canvas
    setup_canvas.create_window((0,0), window=second_setup_frame, anchor="nw")

    instructions_setup_buttons = tk.Label(master=second_setup_frame, text='Run at the end of setup')
    instructions_setup_buttons.config(font=("Arial", 20))
    instructions_setup_buttons.pack()

    frame_1_setup = tk.Frame(master=second_setup_frame, relief = tk.GROOVE, borderwidth=5)
    frame_1_setup.config(bg="black")
    frame_1_setup.pack()
    button_1_setup = tk.Button(master=frame_1_setup, text='Click to setup of files for downloading\nmouse spinner data', width=35, height=2)
    button_1_setup.config(font=("Arial", 14))
    button_1_setup.pack()

    def RunningWheel_Startup(event):

        # Create the Spinner_List
        Spinner_List = ['Spinner_1']
        for n in range(int(ws_Directory.cell(row=20, column=2).value)-1):
            Spinner_List.append('Spinner_' + str(n + 2))

        os.chdir(str(ws_Directory.cell(row=5, column=2).value)) #Changes the directory to where I will be saving the spinner data

        wb_directory = Workbook()   #Creats a new excel workbook that will be used as a directory for all spinners

        ws_length = wb_directory.create_sheet('Length', 0)  #New sheet called "Length"
        ws_length.cell(row=1, column=1).value = 'Spinner'   #Column titles "Spinner", "Files", and "Length"
        ws_length.cell(row=1, column=2).value = 'Files'
        ws_length.cell(row=1, column=3).value = 'Length'

        for n in range(len(Spinner_List)):
            ws_length.cell(row=n+2, column=1).value = Spinner_List[n]   #The name of the spinner (ie. Spinner_1... Spinner_8)
            ws_directory = wb_directory.create_sheet(Spinner_List[n], n+1)  #Creates a sheet that will be th directory for this specific spinner
            ws_directory.cell(row=1, column=1).value = 'File'   #Which the data is on (ie. '_1.xlsx', '_2.xlsx', '_3.xlsx', ect.)
            ws_directory.cell(row=1, column=2).value = 'Tab_Name'   #Tab name will be the date and time that data was downloaded. Each file can contain up to 50 tabs.
            ws_directory.cell(row=1, column=3).value = 'Date'   #Date this data was downloaded
            ws_directory.cell(row=1, column=4).value = 'Length' #length (number of rows) fo the tab containing the data

        for n in range(len(Spinner_List)):
            new_directory = os.makedirs(Spinner_List[n])    #Creates a new folder for each spinner
            wb_data = Workbook()    #Creates a new excel workbook
            wb_data.save(Spinner_List[n] + '/' + Spinner_List[n] + '_1.xlsx')   #Saves this work book as "Spinner#_1.xlsx". This is the first.

        wb_directory.save('Wheel_Directory.xlsx')   #Save excel workbook


        print('The files for downloading mouse spinner data have been setup')

    button_1_setup.bind("<Button-1>", RunningWheel_Startup)



    frame_2_setup = tk.Frame(master=second_setup_frame, relief = tk.GROOVE, borderwidth=5)
    frame_2_setup.config(bg="white")
    frame_2_setup.pack()
    button_2_setup = tk.Button(master=frame_2_setup, text='Click to Close', width=35, height=1)
    button_2_setup.config(font=("Arial", 14))
    button_2_setup.pack()

    def Close_setup(event):
        setup_buttons.destroy()

    button_2_setup.bind("<Button-1>", Close_setup)


frame_7 = tk.Frame(master=second_frame, relief = tk.GROOVE, borderwidth=5)
frame_7.config(bg="black")
frame_7.pack()
button_7 = tk.Button(master=frame_7, text='Run at the end of setup', width=35, height=2)
button_7.config(font=("Arial", 14))
button_7.pack()

def Final_Setup(event):
    open_setup_buttons()
    print('\nYou can now setup the folders for spinner data download')

button_7.bind("<Button-1>", Final_Setup)


frame_close = tk.Frame(master=second_frame, relief = tk.GROOVE, borderwidth=5)
frame_close.config(bg="white")
frame_close.pack()
button_close = tk.Button(master=frame_close, text='Click to Close', width=35, height=1)
button_close.config(font=("Arial", 14))
button_close.pack()

def Close_GUI(event):
    #window.quit()
    window.destroy()

button_close.bind("<Button-1>", Close_GUI)


window.mainloop()
