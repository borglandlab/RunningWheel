import os, re, GETdata_wheel_nowifi
from openpyxl import load_workbook, Workbook
from datetime import datetime, timedelta

def GETdata_wheel_nowifi(Code_Directory, spinlogs, SavedData_Directory, Spinner_List):

	for n in range(len(Spinner_List)):
		print('beginning to transfer data for ' + Spinner_List[n])
		TransferData_nowifi(spinlogs, SavedData_Directory, Spinner_List[n])
		print('transfer process complete for ' + Spinner_List[n])

	os.chdir(Code_Directory)

	length_directory(SavedData_Directory, Spinner_List)

	print('\ntransfer process complete for all spinners from borgland.mousebehaviour@gmail.com\n')	



def TransferData_nowifi(spinlogs, SavedData_Directory, the_spinner):

	os.chdir(SavedData_Directory)

	# Load the data and directory excel files
	Files = sorted(os.listdir(the_spinner))

	for n in range(len(Files)):
		if 'DS' in Files[n]:
			os.remove(the_spinner + '/' + Files[n])

	wb_data = load_workbook(the_spinner + '/' + Files[-1])
	w = 0
	wb_length = len(wb_data.sheetnames)

	if wb_length >= 50:
		wb_data = Workbook()
		w = w + 1

	wb_directory = load_workbook('Wheel_Directory.xlsx')
	# Activate the sheet that corresponds with the appropriate wheel
	ws_directory = wb_directory[the_spinner]

	os.chdir(spinlogs)

	spinnerFile = open("spinlog_" + the_spinner[8:] + ".txt", "r")
	spinnerText = spinnerFile.read()

	# create my regular expressions
	nameRegex = re.compile(r'Spinner_\d{1,3}\sReport')

	dateRegex = re.compile(r'\w\w\w\w\-\w\w\-\w\w\s\w\w\:\w\w\:\w\w')

	readRegex = re.compile(r'\'(\w{1,5}\.\w{1,3})\|(\w{1,3})\|(\w{1,3})\|(\w{1,3})\'')

	DATE = dateRegex.findall(spinnerText)
	#print(DATE)

	os.chdir(SavedData_Directory)

	# Run through this for all but the last entry
	for n in range(len(DATE)-1):

		# get the length of the directory, so that I can put the new values at the bottom
		l = len(ws_directory['A'])	

		location_B = re.search(DATE[n], spinnerText)
		location_E = re.search(DATE[n+1], spinnerText)

		READ = readRegex.findall(spinnerText[location_B.span()[1]:location_E.span()[0]])

		ws_data = wb_data.create_sheet(DATE[n][0:10] + '_' + DATE[n][11:13] + DATE[n][14:16] + DATE[n][17:19], l-1)

		# get the sheet name and the actual date (same things basically, but in different formats)
		ws_directory.cell(row=l+1, column=1).value = the_spinner + '_' + str(len(Files) + w) + '.xlsx'
		ws_directory.cell(row=l+1, column=2).value = DATE[n][0:10] + '_' + DATE[n][11:13] + DATE[n][14:16] + DATE[n][17:19]
		ws_directory.cell(row=l+1, column=3).value = DATE[n]
		
		# create my variable name
		ws_data['A1'] = 'Time'
		ws_data['B1'] = 'Left_value'
		ws_data['C1'] = 'Centre_value'
		ws_data['D1'] = 'Right_value'		

		# use a loop to put all of my data into this table
		for x in range(len(READ)):
			m = x+2
			ws_data.cell(row=m, column=1).value = READ[x][0]
			ws_data.cell(row=m, column=2).value = READ[x][1]
			ws_data.cell(row=m, column=3).value = READ[x][2]
			ws_data.cell(row=m, column=4).value = READ[x][3]
		ws_directory.cell(row=l+1, column=4).value = len(ws_data['A'])

		if len(wb_data.sheetnames) >= 50:
			wb_data.save(the_spinner + '/' + the_spinner + '_' + str(len(Files) + w) + '.xlsx')

			wb_data = Workbook()
			w = w + 1

	# Run through that again for the last entry
	l = len(ws_directory['A'])

	location_B = re.search(DATE[-1], spinnerText)

	READ = readRegex.findall(spinnerText[location_B.span()[1]:-1])

	ws_data = wb_data.create_sheet(DATE[-1][0:10] + '_' + DATE[-1][11:13] + DATE[-1][14:16] + DATE[-1][17:19], l-1)

	# get the sheet name and the actual date (same things basically, but in different formats)
	ws_directory.cell(row=l+1, column=1).value = the_spinner + '_' + str(len(Files) + w) + '.xlsx'
	ws_directory.cell(row=l+1, column=2).value = DATE[-1][0:10] + '_' + DATE[-1][11:13] + DATE[-1][14:16] + DATE[-1][17:19]
	ws_directory.cell(row=l+1, column=3).value = DATE[-1]

	# create my variable name
	ws_data['A1'] = 'Time'
	ws_data['B1'] = 'Left_value'
	ws_data['C1'] = 'Centre_value'
	ws_data['D1'] = 'Right_value'	

	# use a loop to put all of my data into this table
	for x in range(len(READ)):
		m = x+2
		ws_data.cell(row=m, column=1).value = READ[x][0]
		ws_data.cell(row=m, column=2).value = READ[x][1]
		ws_data.cell(row=m, column=3).value = READ[x][2]
		ws_data.cell(row=m, column=4).value = READ[x][3]
	ws_directory.cell(row=l+1, column=4).value = len(ws_data['A'])

	if len(wb_data.sheetnames) >= 50:
		wb_data.save(the_spinner + '/' + the_spinner + '_' + str(len(Files) + w) + '.xlsx')

		wb_data = Workbook()
		w = w + 1

	# Saving my two excel files
	wb_data.save(the_spinner + '/' + the_spinner + '_' + str(len(Files) + w) + '.xlsx')
	wb_directory.save('Wheel_Directory.xlsx')



def length_directory(SavedData_Directory, Spinner_List):
	os.chdir(SavedData_Directory)
	for n in range(len(Spinner_List)):
		wb_directory = load_workbook('Wheel_Directory.xlsx')
		ws_length = wb_directory['Length']
		ws_directory = wb_directory[Spinner_List[n]]

		Files = sorted(os.listdir(Spinner_List[n]))

		ws_length.cell(row=n+2, column=2).value = len(Files)
		ws_length.cell(row=n+2, column=3).value = len(ws_directory['A'])
		wb_directory.save('Wheel_Directory.xlsx')


