function [Directory_Structure] = Import_MAINTable_wMouseWeight(Python_Directory)

%% Set up the Import Options and import the data
opts = spreadsheetImportOptions("NumVariables", 2);

% Specify sheet and range
opts.Sheet = "Directory";
opts.DataRange = "A2:B20";

% Specify column names and types
opts.VariableNames = ["Directory_Type", "Directory"];
opts.VariableTypes = ["string", "string"];

% Specify variable properties
opts = setvaropts(opts, ["Directory_Type", "Directory"], "WhitespaceRule", "preserve");
opts = setvaropts(opts, ["Directory_Type", "Directory"], "EmptyFieldRule", "auto");

% Import the data
Directory_Table = readtable(Python_Directory + "RunningWheel_Setup_ABA.xlsx", opts, "UseExcel", false);


%% Clear temporary variables
clear opts

Directory_Structure.Python_Directory = Directory_Table.Directory(1);
Directory_Structure.MATLAB_RunningWheelDirectory = Directory_Table.Directory(2);
Directory_Structure.MATLAB_GeneralDirectory = Directory_Table.Directory(3);
Directory_Structure.Downloaded_SpinnerData = Directory_Table.Directory(4);
Directory_Structure.MATLAB_PrimarySaved = Directory_Table.Directory(5);
Directory_Structure.MATLAB_SecondarySaved = Directory_Table.Directory(6);

Directory_Structure.MATLAB_MouseWeightDirectory = Directory_Table.Directory(7);
Directory_Structure.Acclimation_Day1 = Directory_Table.Directory(8);
Directory_Structure.MATLAB_RunningWheel_Structure = Directory_Table.Directory(9);
Directory_Structure.MATLAB_MouseWeight_Structure = Directory_Table.Directory(10);
Directory_Structure.Excel_File_Name = Directory_Table.Directory(11);
Directory_Structure.Excel_File_Directory = Directory_Table.Directory(12);

Directory_Structure.MATLAB_TimeZone = Directory_Table.Directory(13);
Directory_Structure.Python_TimeZone = Directory_Table.Directory(14);

Directory_Structure.Spinner_Email_Address = Directory_Table.Directory(15);
Directory_Structure.Spinner_Email_Password = Directory_Table.Directory(16);
Directory_Structure.Alert_Email_Address = Directory_Table.Directory(17);
Directory_Structure.Alert_Threshold = Directory_Table.Directory(18);
Directory_Structure.Wheel_Number = Directory_Table.Directory(19);

clear Directory_Table
end




